const $ = (s) => document.querySelector(s), A = $('#app');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let csrf = '', msg = '';
async function api(path, method = 'GET', body) {
  const r = await fetch(path, { method, headers: { 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-Token': csrf } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.message || r.status), { status: r.status }); return j;
}
const note = (t, bad) => { msg = `<div class="${bad ? 'err' : 'note'}">${esc(t)}</div>`; };
const tm = (t) => (t ? new Date(t).toLocaleString() : '—');

function loginView(err) {
  A.innerHTML = `<div class="card" style="max-width:380px;margin:60px auto"><h2 style="margin-top:0">AIMETA Admin</h2>${err ? `<div class="err">${esc(err)}</div>` : ''}
  <p><input id="u" placeholder="username" autocomplete="username"></p><p><input id="p" type="password" placeholder="password" autocomplete="current-password"></p><button class="btn main" id="go">Login</button></div>`;
  const submit = async () => { try { const j = await api('/api/admin/login', 'POST', { username: $('#u').value, password: $('#p').value }); csrf = j.csrf; load(); } catch (e) { loginView(e.message); } };
  $('#go').onclick = submit; $('#p').onkeydown = (e) => e.key === 'Enter' && submit();
}
const F = { minCandles: [60, 150], staleIntervals: [1, 20], minVolatility: [0, 0.01], strong: [1, 20], medium: [1, 20], rsiHigh: [50, 100], rsiLow: [0, 50], rsiBull: [50, 70], rsiBear: [30, 50] };
const W = ['ema', 'ema2', 'rsi', 'macd', 'momentum', 'levels'];

async function load() {
  let st, se, ins, sg, tx;
  try { [st, se, ins, sg, tx] = await Promise.all([api('/api/admin/status'), api('/api/admin/settings'), api('/api/admin/instruments'), api('/api/admin/signals?limit=50'), api('/api/admin/texts')]); }
  catch (e) { return loginView(e.status === 401 ? '' : e.message); }
  const src = (n) => { const s = st.sources[n], h = s.health; return `<tr><td>${n}</td><td><label><input type="checkbox" data-src="${n}" ${s.enabled ? 'checked' : ''} style="width:auto"> on</label></td><td>${s.configured ? 'key OK' : '<b>no key</b>'}</td><td>ok ${h?.ok ?? 0} / fail ${h?.fail ?? 0}</td><td>${esc(h?.lastError || '')}</td></tr>`; };
  A.innerHTML = `${msg}<div class="row" style="justify-content:space-between"><h2>AIMETA Admin</h2><button class="btn" id="lo">Logout</button></div>
  <div class="card"><h3>Sources</h3><table><tr><th>source</th><th>enabled</th><th>key</th><th>requests</th><th>last error</th></tr>${src('binance')}${src('twelvedata')}</table><p class="mu">AI key: ${st.ai.configured ? 'set' : 'not set'} · instruments: ${st.counts.instruments} · signals: ${st.counts.signals}</p>
  <h4>API errors</h4><table>${st.errors.map((e) => `<tr><td>${tm(e.ts)}</td><td>${esc(e.source)}</td><td>${esc(e.message)}</td></tr>`).join('') || '<tr><td>—</td></tr>'}</table></div>
  <div class="card"><h3>Algorithm settings</h3><div class="row">${Object.entries(F).map(([k, [lo, hi]]) => `<label style="width:150px">${k}<input data-e="${k}" type="number" step="any" min="${lo}" max="${hi}" value="${se.engine[k]}"></label>`).join('')}</div>
  <h4>Weights (0–10)</h4><div class="row">${W.map((k) => `<label style="width:110px">${k}<input data-w="${k}" type="number" step="any" min="0" max="10" value="${se.engine.weights[k]}"></label>`).join('')}</div>
  <h4>Refresh intervals</h4><div class="row"><label style="width:200px">Binance cache, s (1–60)<input id="ttl" type="number" min="1" max="60" value="${se.candleTtlSec}"></label><label style="width:200px">Twelve Data cache, s (15–300)<input id="tdttl" type="number" min="15" max="300" value="${se.tdTtlSec}"></label><label><input type="checkbox" id="aien" ${se.ai.enabled ? 'checked' : ''} style="width:auto"> AI analysis</label></div>
  <p><button class="btn main" id="sv">Save</button></p></div>
  <div class="card"><h3>Instruments (${ins.items.length})</h3><p><input id="fq" placeholder="filter…"></p><div style="max-height:320px;overflow:auto"><table id="it">${ins.items.map((i) => `<tr data-n="${esc(i.name.toLowerCase())}"><td>${esc(i.name)}</td><td>${i.category}/${i.mode}/${i.source}</td><td><label><input type="checkbox" data-en="${esc(i.id)}" ${i.enabled ? 'checked' : ''} style="width:auto"> on</label></td><td><button class="pill" data-del="${esc(i.id)}">delete</button></td></tr>`).join('')}</table></div>
  <h4>Bulk add / replace</h4><p class="mu">One per line: <code>category|symbol|source|mode|name</code> (fx/cr/cm/eq, binance/twelvedata/otc, live/otc)</p><textarea id="bulk" rows="4" placeholder="fx|EUR/USD|twelvedata|live&#10;fx|AED/CNY|otc|otc"></textarea><p><button class="btn" id="bk">Import</button></p></div>
  <div class="card"><h3>Signals (last 50)</h3><div style="overflow:auto"><table><tr><th>time</th><th>instrument</th><th>dir</th><th>hz</th><th>price0</th><th>price1</th><th>result</th></tr>${sg.items.map((s) => `<tr><td>${tm(s.createdAt)}</td><td>${esc(s.instrumentId)}</td><td>${s.direction}</td><td>${s.horizon}</td><td>${s.price0}</td><td>${s.price1 ?? '—'}</td><td>${esc(s.result || s.status)}</td></tr>`).join('')}</table></div></div>
  <div class="card"><h3>Texts</h3><p class="mu">Override an interface text by its key (see i18n.js). Empty value = remove override.</p><div class="row"><input id="tk" placeholder="key e.g. title" style="width:160px"><select id="tl" style="width:90px"><option>ru</option><option>en</option><option>ua</option></select><input id="tv" placeholder="text" style="flex:1"><button class="btn" id="ts">Save</button></div>
  <table>${tx.items.map((t) => `<tr><td>${esc(t.key)}</td><td>${t.lang}</td><td>${esc(t.value)}</td></tr>`).join('')}</table></div>`;
  msg = '';
  const act = (fn) => async (e) => { try { await fn(e); note('Saved'); } catch (er) { note(er.message, true); } load(); };
  $('#lo').onclick = async () => { await api('/api/admin/logout', 'POST').catch(() => {}); csrf = ''; loginView(); };
  A.querySelectorAll('[data-src]').forEach((c) => (c.onchange = act(() => api('/api/admin/settings', 'PUT', { sources: { [c.dataset.src]: c.checked } }))));
  A.querySelectorAll('[data-en]').forEach((c) => (c.onchange = act(() => api('/api/admin/instruments/' + encodeURIComponent(c.dataset.en), 'PUT', { enabled: c.checked }))));
  A.querySelectorAll('[data-del]').forEach((b) => (b.onclick = act(() => confirm('Delete?') && api('/api/admin/instruments/' + encodeURIComponent(b.dataset.del), 'DELETE'))));
  $('#sv').onclick = act(() => { const engine = { weights: {} }; A.querySelectorAll('[data-e]').forEach((i) => (engine[i.dataset.e] = Number(i.value))); A.querySelectorAll('[data-w]').forEach((i) => (engine.weights[i.dataset.w] = Number(i.value)));
    return api('/api/admin/settings', 'PUT', { engine, candleTtlSec: Number($('#ttl').value), tdTtlSec: Number($('#tdttl').value), ai: { enabled: $('#aien').checked } }); });
  $('#bk').onclick = act(async () => { const r = await api('/api/admin/instruments/bulk', 'POST', { text: $('#bulk').value }); if (r.badLines.length) throw new Error(`Added ${r.added}; bad lines: ${r.badLines.join(', ')}`); });
  $('#ts').onclick = act(() => api('/api/admin/texts', 'PUT', { key: $('#tk').value, lang: $('#tl').value, value: $('#tv').value }));
  $('#fq').oninput = (e) => A.querySelectorAll('#it tr').forEach((r) => (r.style.display = r.dataset.n.includes(e.target.value.toLowerCase()) ? '' : 'none'));
}
load();
