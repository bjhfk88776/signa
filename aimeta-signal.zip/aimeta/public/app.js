import { D } from './i18n.js';
const LN = ['ru', 'en', 'ua'], $ = (s) => document.querySelector(s);
const S = { lang: Number(localStorage.getItem('lang')) || 0, v: 'home', cat: 'fx', inst: null, hz: 60, mode: 'all', q: '', sig: null, busy: false, zoom: 80, chart: null, err: '', cfg: { texts: {}, categories: {} } };
// --- Telegram Mini App (поза Telegram цей блок нічого не робить)
const TG = window.Telegram?.WebApp?.initData ? window.Telegram.WebApp : null;
if (TG) {
  TG.ready(); TG.expand();
  try { TG.setHeaderColor('#09050f'); TG.setBackgroundColor('#09050f'); } catch {}
  if (localStorage.getItem('lang') === null) { const l = (TG.initDataUnsafe?.user?.language_code || '').slice(0, 2); S.lang = l === 'uk' ? 2 : l === 'en' ? 1 : 0; }
  TG.BackButton.onClick(() => (S.v === 'inst' ? go('list', S.cat) : go('home')));
}
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const t = (k, ...a) => { let s = S.cfg.texts[k]?.[LN[S.lang]] ?? (D[k] || k).split('|')[S.lang] ?? ''; a.forEach((x, i) => (s = s.replace('{' + i + '}', x))); return s; };
const tm = (ts) => new Date(ts).toLocaleTimeString('ru-RU'), fmt = (p) => (p >= 100 ? p.toFixed(2) : p >= 1 ? p.toFixed(4) : p >= 0.01 ? p.toFixed(5) : p.toFixed(8));

async function api(path, opt) {
  let r; try { r = await fetch(path, TG ? { ...opt, headers: { ...(opt?.headers || {}), 'X-Telegram-Init-Data': TG.initData } } : opt); } catch { throw { code: 'net' }; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw { code: j.error || 'error', message: j.message };
  return j;
}
const errText = (e) => (D[e.code] ? t(e.code) : e.message || e.code);

const go = (v, x) => { S.v = v; S.err = ''; if (v === 'list') { S.cat = x; S.q = ''; S.mode = 'all'; } if (v === 'inst') { S.inst = x; S.sig = null; S.chart = null; } render(); scrollTo(0, 0); };
window.addEventListener('click', (e) => {
  const el = e.target.closest('[data-go]'); if (!el) return;
  const [v, x] = el.dataset.go.split('|'); go(v, x);
});

function bar() {
  return `<div class="bar">${LN.map((l, i) => `<button class="pill ${S.lang === i ? 'on' : ''}" data-lang="${i}">${l.toUpperCase()}</button>`).join('')}<span id="clk"></span><button class="pill" id="rf" aria-label="refresh">⟳</button>${S.v !== 'home' ? `<button class="pill" id="bk">← ${t('back')}</button>` : ''}</div>`;
}
async function render() {
  const a = $('#app'); a.innerHTML = bar() + `<div id="pg"></div>`;
  a.querySelectorAll('[data-lang]').forEach((b) => (b.onclick = () => { S.lang = +b.dataset.lang; localStorage.setItem('lang', S.lang); document.documentElement.lang = ['ru', 'en', 'uk'][S.lang]; render(); }));
  $('#rf').onclick = () => render(); if ($('#bk')) $('#bk').onclick = () => (S.v === 'inst' ? go('list', S.cat) : go('home'));
  if (TG) (S.v === 'home' ? TG.BackButton.hide() : TG.BackButton.show());
  tick();
  try { await ({ home, list, inst, stats })[S.v](); } catch (e) { $('#pg').innerHTML = `<div class="err">${esc(errText(e))}</div>`; }
}

async function home() {
  S.cfg = { ...S.cfg, ...(await api('/api/config')) };
  const ic = { fx: 'FX', cr: 'CR', cm: 'CM', eq: 'EQ' };
  $('#pg').innerHTML = `<h1>${t('title')}</h1><p class="mu">${t('desc')}</p>` + ['fx', 'cr', 'cm', 'eq'].map((c) => { const k = S.cfg.categories[c] || { total: 0, ready: 0 };
    return `<div class="card cat" data-go="list|${c}"><div class="ico">${ic[c]}</div><div><h2 style="margin:0 0 4px">${t(c)}</h2><div class="mu" style="font-size:14px">${t(c + 'd')}</div><div style="margin-top:8px"><span class="tag">${t('n', k.total, k.ready)}</span></div></div><div class="go">→</div></div>`; }).join('')
    + `<div class="card" data-go="stats"><h2 style="margin:0">${t('stat')} →</h2></div>`;
}

let dbt;
async function list() {
  $('#pg').innerHTML = `<div class="card"><h2 style="margin:0 0 4px">${t(S.cat)}</h2><div class="mu">${t(S.cat + 'd')}</div><div class="row" style="margin:12px 0"><button class="btn" data-go="home">⌂ ${t('home')}</button></div><div class="row"><input id="q" placeholder="${esc(t('srch'))}" value="${esc(S.q)}" style="flex:1"><button class="btn" id="rs">${t('reset')}</button></div><div class="row" style="margin-top:10px">${['all', 'live', 'otc'].map((m) => `<button class="pill ${S.mode === m ? 'on' : ''}" data-m="${m}">${m === 'all' ? t('all') : m.toUpperCase()}</button>`).join('')}</div></div><div id="its"><span class="sp"></span></div>`;
  $('#q').oninput = (e) => { S.q = e.target.value; clearTimeout(dbt); dbt = setTimeout(items, 250); };
  $('#rs').onclick = () => { S.q = ''; S.mode = 'all'; list(); };
  document.querySelectorAll('[data-m]').forEach((b) => (b.onclick = () => { S.mode = b.dataset.m; list(); }));
  await items();
}
async function items() {
  const p = new URLSearchParams({ cat: S.cat, q: S.q }); if (S.mode !== 'all') p.set('mode', S.mode);
  const { items: l } = await api('/api/instruments?' + p);
  $('#its').innerHTML = l.map((i) => `<div class="card item ${i.status === 'ready' ? '' : 'off'}" data-go="inst|${esc(i.id)}"><div style="flex:1"><div class="hd" style="font-size:20px;font-weight:800">${esc(i.name)}</div><div class="mu" style="font-size:13px">${i.mode.toUpperCase()} • ${t('st')}: <span class="${i.status === 'ready' ? '' : 'tag bad'}">${t(i.status === 'ready' ? 'ready' : i.status)}</span></div></div><span class="btn">${t(i.category)}</span></div>`).join('') || '<p class="mu">—</p>';
}

let cur; // поточний інструмент
async function inst() {
  const { items: l } = await api('/api/instruments?q=');
  cur = l.find((x) => x.id === S.inst); if (!cur) throw { code: 'not_found', message: 'Not found' };
  const warn = cur.mode === 'otc' ? `<div class="note">${t('otcnote')}</div>` : S.hz === 30 && cur.source !== 'binance' ? `<div class="note">${t('hz30')}</div>` : '';
  $('#pg').innerHTML = `<div class="card"><h2 style="margin:0">${t(cur.category)}</h2><div class="mu">${t('instr')}: <b style="color:var(--tx)">${esc(cur.name)}</b> <span class="tag">${cur.mode.toUpperCase()}</span></div>
  <div class="row" style="margin:12px 0"><button class="btn" data-go="list|${cur.category}">← ${t('tolist')}</button><button class="btn" data-go="home">⌂ ${t('home')}</button></div>
  <div class="mu">${t('price')} <span class="hd" style="font-size:24px;color:var(--tx)" id="px">—</span> <span id="ch"></span> <span style="font-size:12px">${t('chg')}</span> <span class="tag" id="stt">${t(cur.status === 'ready' ? 'ready' : cur.status)}</span> <span class="mu" style="font-size:12px" id="upd"></span></div>
  <div class="card" style="margin:12px 0 0"><div class="mu hd">${t('time')}</div><div class="row" style="margin-top:6px">${[30, 60, 180, 300].map((h) => `<button class="pill ${S.hz === h ? 'on' : ''}" data-h="${h}">${t('s' + h)}</button>`).join('')}</div>${warn}
  <div class="row" style="margin-top:14px"><button class="btn main" id="gs">${t('get')}</button></div><div id="res"></div>
  <div class="row" style="margin:14px 0 6px"><button class="btn" id="zi">${t('zin')}</button><button class="btn" id="zo">${t('zout')}</button></div><div id="cvw"><canvas id="cv"></canvas></div></div></div>
  <div class="card"><h2 style="margin:0 0 8px;font-size:18px">${t('hist')}</h2><div id="hs" style="overflow-x:auto"></div></div>`;
  document.querySelectorAll('[data-h]').forEach((b) => (b.onclick = () => { S.hz = +b.dataset.h; S.sig = null; inst(); }));
  $('#gs').onclick = getSig; $('#zi').onclick = () => { S.zoom = Math.max(30, S.zoom - 20); draw(); }; $('#zo').onclick = () => { S.zoom = Math.min(150, S.zoom + 20); draw(); };
  renderRes(); await Promise.all([loadChart(), loadHist()]);
}
async function loadChart() {
  if (S.v !== 'inst' || !cur) return;
  try { S.chart = await api(`/api/instruments/${encodeURIComponent(cur.id)}/candles?hz=${S.hz}`); $('#stt').textContent = t('ready'); $('#stt').className = 'tag'; const c = S.chart.candles, p = c.at(-1).c, p0 = c.at(-31)?.c ?? c[0].c;
    $('#px').textContent = fmt(p); const d = (p / p0 - 1) * 100; $('#ch').textContent = (d >= 0 ? '+' : '') + d.toFixed(3) + '%'; $('#ch').style.color = d >= 0 ? 'var(--up)' : 'var(--dn)'; $('#upd').textContent = t('updated', tm(S.chart.updatedAt)); draw();
  } catch (e) { S.chart = null; const cw = $('#cvw'); if (cw) cw.innerHTML = `<div class="err">${esc(e.code === 'interval_unsupported' || e.code?.startsWith?.('no_') ? t(e.code === 'no_data' ? 'otcnote' : e.code) : errText(e))}</div>`; const s = $('#stt'); if (s) { s.textContent = t(['no_data', 'source_off', 'not_configured'].includes(e.code) ? e.code : 'no_data'); s.className = 'tag bad'; } }
}
async function getSig() {
  if (S.busy) return; S.busy = true; S.sig = null; $('#gs').disabled = true; $('#res').innerHTML = '<p><span class="sp"></span></p>';
  try { S.sig = await api('/api/signal', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: cur.id, hz: S.hz, lang: LN[S.lang] }) }); }
  catch (e) { $('#res').innerHTML = `<div class="err">${esc(e.code === 'no_data' ? t('otcnote') : errText(e))}</div>`; }
  S.busy = false; $('#gs').disabled = false; if (S.sig) { renderRes(); try { TG?.HapticFeedback.notificationOccurred(S.sig.decision === 'UNAVAILABLE' ? 'warning' : 'success'); } catch {} } loadHist(); loadChart();
}
function renderRes() {
  const g = S.sig, r = $('#res'); if (!r || !g) return;
  if (g.decision === 'UNAVAILABLE') { r.innerHTML = `<div class="big UNAVAILABLE">${t('UNAVAILABLE')}</div><ul>${g.reasons.map((x) => `<li>${esc(t(x))}</li>`).join('')}</ul>`; return; }
  const a = g.ai;
  r.innerHTML = `<div class="big ${g.decision}">${t(g.decision)}</div><div style="font-weight:700;margin-top:6px">${t('strL')}: ${t('str' + g.strength)}${g.conflict ? ' · ' + t('conf2') : ''}</div><div class="mu" style="font-size:13px" id="cd"></div>
  <details style="margin-top:8px"><summary class="hd" style="cursor:pointer">${t('fac')}</summary><div class="mu" style="font-size:13px">${t('sc', g.bull, g.bear)}</div><ul>${g.reasons.map((x) => `<li>${esc(t(x))}</li>`).join('')}</ul>
  ${a ? `<div class="card" style="padding:12px"><div class="hd">${t('aiT')}: <span class="${a.verdict}">${a.verdict === 'CALL' ? '▲' : '▼'}</span> <span class="mu" style="font-size:12px">(${t('conf')}: ${esc(a.confidence)})</span></div><ul>${a.factors.map((x) => `<li>${esc(x)}</li>`).join('')}</ul><div>${esc(a.summary)}</div><div class="mu" style="font-size:13px">${t('risk')}: ${esc(a.risks)}</div></div>` : ''}</details>
  <div class="mu" style="font-size:12px;margin-top:6px">${tm(g.createdAt)} · ${t('exp', tm(g.expiresAt))} · ${t('est')}</div>`;
}
async function loadHist() {
  const e = $('#hs'); if (!e || !cur) return; const { items: l } = await api(`/api/signals?id=${encodeURIComponent(cur.id)}&limit=10`); S.hist = l;
  e.innerHTML = l.length ? `<table><tr><th>${t('time')}</th><th>${t('sig')}</th><th>${t('price')}</th><th>→</th><th></th></tr>${l.map((h) => `<tr><td>${tm(h.createdAt)} (${h.horizon}s)</td><td class="${h.direction}">${h.direction === 'CALL' ? '▲' : '▼'}</td><td>${fmt(h.price0)}</td><td>${h.price1 ? fmt(h.price1) : '—'}</td><td>${h.result ? t(h.result) : t('pend')}</td></tr>`).join('')}</table>` : '<span class="mu">—</span>'; draw();
}
function draw() {
  const cv = $('#cv'), d = S.chart; if (!cv || !d) return;
  const n = Math.min(S.zoom, d.candles.length), cs = d.candles.slice(-n), dpr = devicePixelRatio || 1, W = cv.clientWidth, Ht = cv.clientHeight; cv.width = W * dpr; cv.height = Ht * dpr;
  const x = cv.getContext('2d'); x.scale(dpr, dpr);
  let hi = Math.max(...cs.map((k) => k.h)), lo = Math.min(...cs.map((k) => k.l)); const pd = (hi - lo) * 0.08 || hi * 1e-4; hi += pd; lo -= pd;
  const Y = (p) => Ht - ((p - lo) / (hi - lo)) * (Ht - 16) - 8, w = W / cs.length;
  x.strokeStyle = 'rgba(167,139,250,.12)'; for (let g = 1; g < 5; g++) { x.beginPath(); x.moveTo(0, (g * Ht) / 5); x.lineTo(W, (g * Ht) / 5); x.stroke(); }
  cs.forEach((k, j) => { const up = k.c >= k.o; x.strokeStyle = x.fillStyle = up ? '#34d399' : '#fb7185'; const cx = j * w + w / 2; x.beginPath(); x.moveTo(cx, Y(k.h)); x.lineTo(cx, Y(k.l)); x.stroke(); x.fillRect(cx - w * 0.35, Math.min(Y(k.o), Y(k.c)), w * 0.7, Math.max(1, Math.abs(Y(k.o) - Y(k.c)))); });
  [[d.ema9, '#22d3ee'], [d.ema21, '#a78bfa'], [d.ema50, '#fbbf24']].forEach(([a, col]) => { x.strokeStyle = col; x.lineWidth = 1.4; x.beginPath(); a.slice(-n).forEach((v, j) => (j ? x.lineTo(j * w + w / 2, Y(v)) : x.moveTo(w / 2, Y(v)))); x.stroke(); }); x.lineWidth = 1;
  const stepMs = d.interval === '1s' ? 1000 : 60000; x.font = 'bold 12px sans-serif';
  (S.hist || []).filter((h) => h.horizon === S.hz).forEach((h) => { const j = cs.findIndex((k) => h.createdAt >= k.t && h.createdAt < k.t + stepMs + stepMs); if (j < 0) return; x.fillStyle = h.direction === 'CALL' ? '#34d399' : '#fb7185'; x.fillText(h.direction === 'CALL' ? '▲' : '▼', j * w, h.direction === 'CALL' ? Y(cs[j].l) + 14 : Y(cs[j].h) - 4); });
}
async function stats() {
  const s = await api('/api/stats'), pc = (v) => (v * 100).toFixed(1) + '%';
  const row = (k, o) => `<tr><td>${esc(k)}</td><td>${o.checked}</td><td>${o.correct}</td><td>${o.wrong}</td><td>${o.rate ? pc(o.rate.p) : '—'}</td></tr>`;
  $('#pg').innerHTML = `<div class="card"><h2 style="margin:0 0 8px">${t('stat')}</h2><div class="row" style="margin-bottom:10px"><button class="btn" data-go="home">⌂ ${t('home')}</button></div>
  ${s.total ? `<div>${t('st1', s.checked, s.correct, s.wrong, s.undetermined, s.pending)}</div><div class="mu">${t('st2', s.call, s.put)}</div>
  ${s.rate ? `<div style="margin-top:6px;font-weight:700">${t('st3', pc(s.rate.p), pc(s.rate.lo), pc(s.rate.hi), s.rate.n)}</div>${s.rate.n < 30 ? `<div class="note">${t('st4')}</div>` : ''}` : ''}
  <div class="mu" style="font-size:12px;margin-top:6px">${t('st5', new Date(s.startedAt).toLocaleString(), s.lastCheckedAt ? new Date(s.lastCheckedAt).toLocaleString() : '—')}</div>` : `<div class="mu">${t('nost')}</div>`}</div>
  ${s.total ? `<div class="card"><h2 style="margin:0 0 8px;font-size:18px">${t('byH')}</h2><table><tr><th></th><th>n</th><th>✓</th><th>✗</th><th>%</th></tr>${Object.entries(s.byHorizon).map(([k, o]) => row(k + 's', o)).join('')}</table></div>
  <div class="card"><h2 style="margin:0 0 8px;font-size:18px">${t('byI')}</h2><table><tr><th></th><th>n</th><th>✓</th><th>✗</th><th>%</th></tr>${Object.entries(s.byInstrument).slice(0, 40).map(([k, o]) => row(k, o)).join('')}</table></div>` : ''}`;
}
function tick() {
  const c = $('#clk'); if (c) c.textContent = new Date().toLocaleTimeString('ru-RU');
  const cd = $('#cd'); if (cd && S.sig?.expiresAt) { const l = Math.round((S.sig.expiresAt - Date.now()) / 1000); cd.textContent = l > 0 ? t('left', l) : '✓'; }
}
setInterval(tick, 1000);
setInterval(() => { if (S.v === 'inst' && !document.hidden) loadChart(); }, 4000);
addEventListener('resize', () => { if (S.v === 'inst') draw(); });
render();
