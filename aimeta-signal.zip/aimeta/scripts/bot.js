// BOT_TOKEN=... WEBAPP_URL=https://ваш-домен node scripts/bot.js
import { createBot } from '../src/bot.js';
try { await createBot({ token: process.env.BOT_TOKEN, url: process.env.WEBAPP_URL }).run(); }
catch (e) { console.error(e.message); process.exit(1); }
