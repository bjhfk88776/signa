// Створення/зміна адміністратора. Пароль береться лише зі змінних середовища, у коді його немає.
//   ADMIN_USER=admin ADMIN_PASSWORD='довгий-пароль-12+' node scripts/create-admin.js
import { openDb } from '../src/db.js';
import { hashPassword } from '../src/auth.js';
const { ADMIN_USER: u, ADMIN_PASSWORD: p } = process.env;
if (!u || !/^[A-Za-z0-9_.-]{3,32}$/.test(u)) { console.error('ADMIN_USER: 3-32 символи (літери, цифри, _ . -)'); process.exit(1); }
if (!p || p.length < 12) { console.error('ADMIN_PASSWORD: щонайменше 12 символів'); process.exit(1); }
const db = openDb(process.env.DB_FILE || 'data/aimeta.db');
db.prepare('INSERT INTO admins(username,hash) VALUES(?,?) ON CONFLICT(username) DO UPDATE SET hash=excluded.hash').run(u, hashPassword(p));
db.prepare('DELETE FROM sessions WHERE username=?').run(u);
console.log(`Адміністратора "${u}" збережено.`);
