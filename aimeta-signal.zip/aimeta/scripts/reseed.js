// Повністю замінює каталог інструментів списком із src/seed.js (історія сигналів не видаляється).
import { openDb } from '../src/db.js';
import { seed } from '../src/seed.js';
const db = openDb(process.env.DB_FILE || 'data/aimeta.db');
db.exec('DELETE FROM instruments'); seed(db);
console.log('Каталог оновлено:', db.prepare('SELECT category, mode, COUNT(*) n FROM instruments GROUP BY category, mode').all().map((r) => `${r.category}/${r.mode}=${r.n}`).join(' '));
