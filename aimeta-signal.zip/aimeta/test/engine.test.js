import test from 'node:test';
import assert from 'node:assert/strict';
import { analyze } from '../src/engine.js';
import { DEFAULT } from '../src/config.js';
import { BinanceProvider } from '../src/providers/binance.js';

// детермінований «шумний» тренд
const series = (n, step) => { let p = 100, s = 7; return Array.from({ length: n }, (_, i) => {
  s = (s * 16807) % 2147483647; const noise = (s / 2147483647 - 0.5) * 0.4; p += step + noise;
  return { t: i * 6e4, o: p - 0.05, h: p + 0.2, l: p - 0.2, c: p, closeTime: i * 6e4 + 59999 }; }); };

test('мало свічок -> UNAVAILABLE', () => assert.equal(analyze(series(20, 0.1)).decision, 'UNAVAILABLE'));
test('застарілі дані -> UNAVAILABLE', () => {
  const cs = series(100, 0.1);
  assert.equal(analyze(cs, { now: cs.at(-1).closeTime + 10 * 60000 }).decision, 'UNAVAILABLE');
});
test('некоректні дані (NaN) -> UNAVAILABLE', () => { const cs = series(100, 0.1); cs[50].c = NaN; assert.equal(analyze(cs).decision, 'UNAVAILABLE'); });
test('стійке зростання -> CALL', () => assert.equal(analyze(series(120, 0.3)).decision, 'CALL'));
test('стійке падіння -> PUT', () => assert.equal(analyze(series(120, -0.3)).decision, 'PUT'));
test('результат детермінований', () => { const cs = series(120, 0.1); assert.deepEqual(analyze(cs), analyze(cs)); });
test('пояснення та оцінки повертаються', () => { const r = analyze(series(120, 0.3)); assert.ok(r.reasons.length > 0 && r.bull > r.bear && r.strength >= 1); });
test('пороги з конфігурації впливають на результат', () => {
  const cs = series(120, 0.3);
  assert.equal(analyze(cs, {}, { ...DEFAULT, strong: 1 }).strength, 3);
  assert.equal(analyze(cs, {}, { ...DEFAULT, strong: 99, medium: 98 }).strength, 1);
});

const rows = (n, t0 = 1e12) => Array.from({ length: n }, (_, i) => [t0 + i * 6e4, '1', '2', '0.5', '1.5', '10', t0 + i * 6e4 + 59999]);
test('Binance: розбирає свічки', async () => {
  const p = new BinanceProvider({ fetchImpl: async () => ({ ok: true, status: 200, json: async () => rows(3) }), pauseMs: 0 });
  const cs = await p.getCandles('BTCUSDT', '1m', 3);
  assert.equal(cs.length, 3); assert.deepEqual(Object.keys(cs[0]).sort(), ['c', 'closeTime', 'h', 'l', 'o', 't', 'v']); assert.equal(cs[0].h, 2);
});
test('Binance: помилки 429 / 451 / HTTP / мережа дають зрозумілі повідомлення', async () => {
  const mk = (status) => new BinanceProvider({ fetchImpl: async () => ({ ok: false, status }), pauseMs: 0 });
  await assert.rejects(mk(429).getCandles('X', '1m', 1), /rate limit/);
  await assert.rejects(mk(451).getCandles('X', '1m', 1), /region blocked/);
  await assert.rejects(mk(500).getCandles('X', '1m', 1), /HTTP 500/);
  const net = new BinanceProvider({ fetchImpl: async () => { throw new TypeError('x'); }, pauseMs: 0 });
  await assert.rejects(net.getCandles('X', '1m', 1), /network/);
});
test('Binance: непідтримуваний інтервал відхиляється', async () => assert.rejects(new BinanceProvider().getCandles('X', '7m', 1), /Unsupported/));
test('Binance: відкинута незакрита свічка', async () => {
  const future = Date.now() + 60000;
  const p = new BinanceProvider({ fetchImpl: async () => ({ ok: true, status: 200, json: async () => [...rows(2), [future, '1', '1', '1', '1', '1', future + 59999]] }), pauseMs: 0 });
  assert.equal((await p.getCandles('X', '1m', 3)).length, 2);
});

test('профілі горизонтів: різні періоди індикаторів дають різні значення', () => {
  const cs = series(150, 0.05);
  const a = analyze(cs, { horizon: 30 }), b = analyze(cs, { horizon: 300 });
  assert.deepEqual(a.emaPeriods, [3, 8, 13]); assert.deepEqual(b.emaPeriods, [9, 21, 50]);
  assert.notEqual(a.ema9, b.ema9);
  assert.deepEqual(analyze(cs, {}).emaPeriods, [9, 21, 50]);   // без горизонту — профіль за замовчуванням
  assert.deepEqual(analyze(cs, { horizon: 30 }), analyze(cs, { horizon: 30 })); // детермінованість
});
