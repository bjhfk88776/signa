import test from 'node:test';
import assert from 'node:assert/strict';
import { ema, rsi, atr, macd, levels } from '../src/indicators.js';
import { wilson, breakEven } from '../src/stats.js';

const flat = (n, v = 10) => Array.from({ length: n }, () => v);
const candles = (c) => c.map((x) => ({ o: x, h: x + 1, l: x - 1, c: x }));

test('EMA сталого ряду дорівнює цьому значенню', () => { ema(flat(30), 9).forEach((v) => assert.ok(Math.abs(v - 10) < 1e-12)); });
test('EMA відомий приклад (p=3)', () => { const e = ema([1, 2, 3, 4], 3); assert.deepEqual(e.map((x) => +x.toFixed(4)), [1, 1.5, 2.25, 3.125]); });
test('RSI зростаючого ряду = 100, спадного = 0', () => {
  assert.equal(rsi(Array.from({ length: 40 }, (_, i) => i)), 100);
  assert.ok(rsi(Array.from({ length: 40 }, (_, i) => 100 - i)) < 1e-9);
});
test('RSI повертає null, якщо даних мало', () => assert.equal(rsi([1, 2, 3]), null));
test('ATR свічок сталого діапазону дорівнює діапазону', () => assert.ok(Math.abs(atr(candles(flat(40)), 14) - 2) < 1e-9));
test('MACD сталого ряду має нульову гістограму', () => macd(flat(60)).hist.forEach((v) => assert.ok(Math.abs(v) < 1e-12)));
test('рівні: знаходить опір і підтримку', () => {
  const cs = [5, 6, 9, 6, 5, 4, 1, 4, 5].map((x) => ({ o: x, h: x, l: x, c: x }));
  const lv = levels(cs); assert.deepEqual(lv.resistance, [9]); assert.deepEqual(lv.support, [1]);
});
test('Вілсон: 50/100 охоплює 0.5, межі в [0,1]', () => { const w = wilson(50, 100); assert.ok(w.lo < 0.5 && w.hi > 0.5 && w.lo > 0 && w.hi < 1); });
test('беззбитковість при виплаті 85% ≈ 54.05%', () => assert.ok(Math.abs(breakEven(0.85) - 0.5405) < 1e-3));
