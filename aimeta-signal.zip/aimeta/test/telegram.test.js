import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { verifyInitData } from '../src/telegram.js';
import { createBot } from '../src/bot.js';
import { openDb } from '../src/db.js';
import { seed } from '../src/seed.js';
import { SignalService } from '../src/service.js';
import { createApp } from '../src/server.js';

const TOKEN = '123456:TEST-TOKEN';
export const sign = (fields, token = TOKEN) => {
  const check = Object.entries(fields).sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const hash = crypto.createHmac('sha256', crypto.createHmac('sha256', 'WebAppData').update(token).digest()).update(check).digest('hex');
  return new URLSearchParams({ ...fields, hash }).toString();
};
const fresh = (id, extra = {}) => sign({ auth_date: String(Math.floor(Date.now() / 1000)), user: JSON.stringify({ id, language_code: 'uk' }), ...extra });

test('initData: валідний підпис приймається', () => assert.equal(verifyInitData(fresh(7), TOKEN).user.id, 7));
test('initData: чужий токен, підміна, старі дані, сміття відхиляються', () => {
  assert.equal(verifyInitData(fresh(7), 'other:token'), null);
  assert.equal(verifyInitData(fresh(7).replace('%22id%22%3A7', '%22id%22%3A8'), TOKEN), null);
  assert.equal(verifyInitData(sign({ auth_date: String(Math.floor(Date.now() / 1000) - 999999), user: '{"id":1}' }), TOKEN), null);
  assert.equal(verifyInitData('hash=zz', TOKEN), null); assert.equal(verifyInitData('', TOKEN), null); assert.equal(verifyInitData(fresh(7), ''), null);
});
test('бот: /start відповідає кнопкою web_app мовою користувача', async () => {
  const sent = []; const bot = createBot({ token: 'T', url: 'https://x.example', fetchImpl: async (u, o) => { sent.push([u, JSON.parse(o.body)]); return { json: async () => ({ ok: true, result: {} }) }; } });
  assert.equal(await bot.handle({ message: { text: '/start', chat: { id: 5 }, from: { language_code: 'uk' } } }), true);
  assert.match(sent[0][0], /sendMessage/); assert.equal(sent[0][1].reply_markup.inline_keyboard[0][0].web_app.url, 'https://x.example'); assert.match(sent[0][1].text, /міні-застосунок/);
  assert.equal(await bot.handle({ message: { text: 'hello', chat: { id: 5 } } }), false);
});
test('бот: потрібен https-URL і токен; помилки Telegram видно', async () => {
  assert.throws(() => createBot({ token: 'T', url: 'http://x' })); assert.throws(() => createBot({ token: '', url: 'https://x' }));
  const bot = createBot({ token: 'T', url: 'https://x', fetchImpl: async () => ({ json: async () => ({ ok: false, description: 'Unauthorized' }) }) });
  await assert.rejects(bot.call('getMe'), /Unauthorized/);
});
test('Mini App: ліміт сигналів рахується на користувача Telegram, а не на IP; CSP дозволяє Telegram, адмінка — ні', async () => {
  const db = openDb(); seed(db);
  const prov = { configured: true, async getCandles() { const now = Date.now(); let p = 100; return Array.from({ length: 150 }, (_, i) => { p += 0.3; const ct = now - 1000 - (149 - i) * 60000; return { t: ct - 59999, o: p - .05, h: p + .2, l: p - .2, c: p, v: 1, closeTime: ct }; }); }, async priceAt() { return 1; } };
  const service = new SignalService({ db, providers: { binance: prov, twelvedata: prov }, ai: async () => null });
  const server = createApp({ db, service, botToken: TOKEN }); await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}`;
  const post = (init) => fetch(url + '/api/signal', { method: 'POST', headers: { 'Content-Type': 'application/json', ...(init ? { 'X-Telegram-Init-Data': init } : {}) }, body: JSON.stringify({ id: 'cr:ETHUSDT', hz: 60 }) }).then((r) => r.status);
  const a = fresh(1), b = fresh(2); for (let i = 0; i < 15; i++) assert.equal(await post(a), 200);
  assert.equal(await post(a), 429);   // користувач 1 вичерпав ліміт
  assert.equal(await post(b), 200);   // користувач 2 з тієї ж IP — ні
  assert.equal(await post('hash=bad'), 200); // підроблений заголовок рахується як звичайна IP, а не як Telegram-користувач
  const home = await fetch(url + '/'), adm = await fetch(url + '/admin.html');
  assert.match(home.headers.get('content-security-policy'), /telegram\.org/); assert.match(home.headers.get('content-security-policy'), /frame-ancestors https:\/\/web\.telegram\.org/);
  assert.match(adm.headers.get('content-security-policy'), /frame-ancestors 'none'/); assert.equal(adm.headers.get('x-frame-options'), 'DENY');
  server.closeAllConnections(); server.close();
});
