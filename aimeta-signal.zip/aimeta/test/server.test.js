import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../src/db.js';
import { seed } from '../src/seed.js';
import { SignalService } from '../src/service.js';
import { createApp } from '../src/server.js';
import { hashPassword } from '../src/auth.js';

const trend = (step, n = 150) => { let p = 100, s = 7; const now = Date.now(); return Array.from({ length: n }, (_, i) => {
  s = (s * 16807) % 2147483647; p += step + (s / 2147483647 - 0.5) * 0.4;
  const closeTime = now - 1000 - (n - 1 - i) * 60000; return { t: closeTime - 59999, o: p - 0.05, h: p + 0.2, l: p - 0.2, c: p, v: 1, closeTime }; }); };
const fakeProvider = (o = {}) => ({ configured: true, calls: 0, async getCandles() { this.calls++; if (o.fail) throw new Error('boom'); return trend(o.step ?? 0.3); }, async priceAt() { return o.price1 === undefined ? 150 : o.price1; } });

const opened = [];
test.after(() => opened.forEach((x) => { x.closeAllConnections(); x.close(); }));
async function start({ binance = fakeProvider(), twelvedata = fakeProvider(), ai = async () => null } = {}) {
  const db = openDb(); seed(db);
  db.prepare('INSERT INTO admins(username,hash) VALUES(?,?)').run('boss', hashPassword('correct-horse-battery'));
  const service = new SignalService({ db, providers: { binance, twelvedata }, ai });
  const server = createApp({ db, service }); opened.push(server); await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}`;
  const req = async (path, { method = 'GET', body, cookie, csrf, raw } = {}) => {
    const r = await fetch(url + path, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}), ...(csrf ? { 'X-CSRF-Token': csrf } : {}) }, body: raw ?? (body ? JSON.stringify(body) : undefined) });
    return { status: r.status, headers: r.headers, json: await r.json().catch(() => null) };
  };
  const login = async () => { const r = await req('/api/admin/login', { method: 'POST', body: { username: 'boss', password: 'correct-horse-battery' } }); return { cookie: r.headers.get('set-cookie').split(';')[0], csrf: r.json.csrf }; };
  return { db, service, req, login, url, close: async () => { server.closeAllConnections(); } };
}
const BTC = 'cr:ETHUSDT', EUR = 'fx:EUR/USD', OTC = 'fx:AED/CNY:otc';

test('каталог: лічильники, пошук, фільтр, здоров’я', async () => {
  const a = await start();
  assert.equal((await a.req('/api/health')).json.ok, true);
  const c = (await a.req('/api/config')).json; assert.equal(Object.values(c.categories).reduce((x, k) => x + k.total, 0), a.db.prepare('SELECT COUNT(*) n FROM instruments').get().n); assert.ok(c.categories.fx.otc >= 1 && c.categories.cm.total >= 1);
  assert.equal((await a.req('/api/instruments?cat=cr&q=ethereum&mode=live')).json.items.length, 1);
  assert.ok((await a.req('/api/instruments?mode=otc')).json.items.every((i) => i.mode === 'otc'));
  await a.close();
});
test('OTC без достовірного джерела: ні графіка, ні сигналу', async () => {
  const a = await start();
  assert.equal((await a.req(`/api/instruments/${encodeURIComponent(OTC)}/candles?hz=60`)).json.error, 'no_data');
  const r = await a.req('/api/signal', { method: 'POST', body: { id: OTC, hz: 60 } }); assert.equal(r.status, 422); assert.equal(r.json.error, 'no_data');
  assert.equal(a.db.prepare('SELECT COUNT(*) n FROM signals').get().n, 0); await a.close();
});
test('Twelve Data без ключа / 30 с на ньому недоступні', async () => {
  const a = await start({ twelvedata: { configured: false } });
  assert.equal((await a.req('/api/signal', { method: 'POST', body: { id: EUR, hz: 60 } })).json.error, 'not_configured'); await a.close();
  const b = await start();
  assert.equal((await b.req('/api/signal', { method: 'POST', body: { id: EUR, hz: 30 } })).json.error, 'interval_unsupported'); await b.close();
});
test('сигнал: CALL на висхідних даних, зберігається, є пояснення', async () => {
  const a = await start();
  const r = (await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json;
  assert.equal(r.decision, 'CALL'); assert.ok(r.reasons.length && r.strength >= 1 && r.expiresAt - r.createdAt === 60000);
  assert.equal((await a.req(`/api/signals?id=${encodeURIComponent(BTC)}`)).json.items.length, 1); await a.close();
});
test('ШІ: збіг підсилює, розбіжність робить сигнал слабким', async () => {
  const ok = await start({ ai: async () => ({ verdict: 'CALL', confidence: 'high', factors: ['x'], summary: 's', risks: 'r' }) });
  const plain = await start(); const base = (await plain.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json;
  const r1 = (await ok.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json; assert.equal(r1.conflict, false); assert.ok(r1.strength >= base.strength);
  const bad = await start({ ai: async () => ({ verdict: 'PUT', confidence: 'medium', factors: [], summary: '', risks: '' }) });
  const r2 = (await bad.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json; assert.equal(r2.conflict, true); assert.equal(r2.strength, 1); assert.equal(r2.decision, 'CALL');
  await ok.close(); await bad.close();
});
async function overdue(a, price1) {
  a.service.providers.binance.priceAt = async () => price1;
  const id = (await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json.id;
  a.db.prepare('UPDATE signals SET expires_at=? WHERE id=?').run(Date.now() - 5000, id); await a.service.verifyDue();
  return a.db.prepare('SELECT * FROM signals WHERE id=?').get(id);
}
test('перевірка: вірний / невірний / нічия', async () => {
  const a = await start(); const p0 = trend(0.3).at(-1).c;
  assert.equal((await overdue(a, p0 + 5)).result, 'correct');
  assert.equal((await overdue(a, p0 - 5)).result, 'wrong');
  const s = a.service.stats(); assert.equal(s.correct, 1); assert.equal(s.wrong, 1); assert.equal(s.rate.n, 2); assert.equal(s.call + s.put, 2); await a.close();
});
test('перевірка: немає ціни після 10 хв -> undetermined; до того чекаємо', async () => {
  const a = await start();
  const r = (await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json; a.service.providers.binance.priceAt = async () => null;
  a.db.prepare('UPDATE signals SET expires_at=? WHERE id=?').run(Date.now() - 5000, r.id); await a.service.verifyDue();
  assert.equal(a.db.prepare('SELECT status FROM signals WHERE id=?').get(r.id).status, 'pending');
  a.db.prepare('UPDATE signals SET expires_at=? WHERE id=?').run(Date.now() - 11 * 60000, r.id); await a.service.verifyDue();
  assert.equal(a.db.prepare('SELECT result FROM signals WHERE id=?').get(r.id).result, 'undetermined'); await a.close();
});
test('невдалі сигнали не зникають зі статистики', async () => {
  const a = await start(); const p0 = trend(0.3).at(-1).c; await overdue(a, p0 - 5); await overdue(a, p0 - 5);
  const s = (await a.req('/api/stats')).json; assert.equal(s.wrong, 2); assert.equal(s.rate.p, 0); await a.close();
});
test('валідація входу та помилки', async () => {
  const a = await start();
  assert.equal((await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 45 } })).status, 400);
  assert.equal((await a.req('/api/signal', { method: 'POST', body: { id: 'nope', hz: 60 } })).status, 404);
  assert.equal((await a.req('/api/signal', { method: 'POST', raw: '{bad' })).status, 400);
  assert.equal((await a.req('/api/signal', { method: 'POST', raw: JSON.stringify({ x: 'a'.repeat(40000) }) })).status, 413);
  await a.close();
});
test('помилка провайдера -> 502, обліковується в статусі', async () => {
  const a = await start({ binance: fakeProvider({ fail: true }) });
  const r = await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } }); assert.equal(r.status, 502);
  const s = await a.login(); const st = (await a.req('/api/admin/status', s)).json;
  assert.equal(st.sources.binance.health.fail, 1); assert.match(st.errors[0].message, /boom/); await a.close();
});
test('кеш: повторні запити не б’ють у джерело', async () => {
  const p = fakeProvider(); const a = await start({ binance: p });
  for (let i = 0; i < 3; i++) await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } });
  assert.equal(p.calls, 1); await a.close();
});
test('ліміт сигналів з однієї адреси', async () => {
  const a = await start(); let last;
  for (let i = 0; i < 16; i++) last = await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } });
  assert.equal(last.status, 429); await a.close();
});
test('адмінка: доступ лише після входу, CSRF, валідація', async () => {
  const a = await start();
  assert.equal((await a.req('/api/admin/status')).status, 401);
  assert.equal((await a.req('/api/admin/login', { method: 'POST', body: { username: 'boss', password: 'wrong' } })).status, 401);
  assert.equal((await a.req('/api/admin/login', { method: 'POST', body: { username: 'nobody', password: 'x' } })).status, 401);
  const s = await a.login();
  assert.equal((await a.req('/api/admin/status', s)).status, 200);
  assert.equal((await a.req('/api/admin/settings', { ...s, method: 'PUT', csrf: undefined, body: { candleTtlSec: 5 } })).status, 403);
  assert.equal((await a.req('/api/admin/settings', { ...s, method: 'PUT', body: { candleTtlSec: 5 } })).json.candleTtlSec, 5);
  assert.equal((await a.req('/api/admin/settings', { ...s, method: 'PUT', body: { candleTtlSec: 999 } })).status, 400);
  assert.equal((await a.req('/api/admin/settings', { ...s, method: 'PUT', body: { engine: { strong: 'x' } } })).status, 400);
  await a.req('/api/admin/logout', { ...s, method: 'POST' });
  assert.equal((await a.req('/api/admin/status', s)).status, 401); await a.close();
});
test('адмінка: блокування після 5 невдалих входів', async () => {
  const a = await start(); let r;
  for (let i = 0; i < 6; i++) r = await a.req('/api/admin/login', { method: 'POST', body: { username: 'boss', password: 'bad' + i } });
  assert.equal(r.status, 429); await a.close();
});
test('адмінка: пороги змінюють результат, джерело можна вимкнути', async () => {
  const a = await start(); const s = await a.login();
  await a.req('/api/admin/settings', { ...s, method: 'PUT', body: { engine: { strong: 1 } } });
  assert.equal((await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json.strength, 3);
  await a.req('/api/admin/settings', { ...s, method: 'PUT', body: { sources: { binance: false } } });
  assert.equal((await a.req('/api/signal', { method: 'POST', body: { id: BTC, hz: 60 } })).json.error, 'source_off'); await a.close();
});
test('адмінка: вимкнений інструмент зникає, імпорт, тексти', async () => {
  const a = await start(); const s = await a.login();
  await a.req(`/api/admin/instruments/${encodeURIComponent(BTC)}`, { ...s, method: 'PUT', body: { enabled: false } });
  assert.equal((await a.req('/api/instruments?cat=cr&q=ethereum&mode=live')).json.items.length, 0);
  const b = (await a.req('/api/admin/instruments/bulk', { ...s, method: 'POST', body: { text: 'fx|EUR/SEK|twelvedata|live\nбрак' } })).json; assert.equal(b.added, 1); assert.deepEqual(b.badLines, [2]);
  assert.equal((await a.req('/api/instruments?q=EUR/SEK')).json.items.length, 1);
  await a.req('/api/admin/texts', { ...s, method: 'PUT', body: { key: 'title', lang: 'ru', value: 'МОЙ ЗАГОЛОВОК' } });
  assert.equal((await a.req('/api/config')).json.texts.title.ru, 'МОЙ ЗАГОЛОВОК');
  assert.equal((await a.req('/api/admin/texts', { ...s, method: 'PUT', body: { key: 'Bad Key!', lang: 'ru', value: 'x' } })).status, 400); await a.close();
});
test('статика: заголовки безпеки, обхід шляхів заблоковано', async () => {
  const a = await start();
  const r = await fetch(a.url + '/'); assert.equal(r.status, 200); assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal((await fetch(a.url + '/..%2f..%2fpackage.json')).status, 404);
  assert.equal((await fetch(a.url + '/admin')).status, 200); await a.close();
});
