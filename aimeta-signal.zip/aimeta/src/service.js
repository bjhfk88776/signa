import { analyze } from './engine.js';
import { DEFAULT } from './config.js';
import { ema } from './indicators.js';
import { wilson } from './stats.js';
import { getSetting, logEvent } from './db.js';
import { TTLCache } from './cache.js';
import { askAI } from './ai.js';

export const HORIZONS = [30, 60, 180, 300];
const IVS = { binance: { 30: '1s', 60: '1m', 180: '1m', 300: '1m' }, twelvedata: { 30: null, 60: '1m', 180: '1m', 300: '1m' } };
const IVMS = { '1s': 5000, '1m': 60000 }; // для перевірки "свіжості"; для 1с-свічок беремо запас 5 с

export class ServiceError extends Error {
  constructor(code, message, http = 422) { super(message || code); this.code = code; this.http = http; }
}

export class SignalService {
  constructor({ db, providers, ai = askAI, now = Date.now }) {
    Object.assign(this, { db, providers, ai, now }); this.cache = new TTLCache(now); this.health = {};
  }
  settings() {
    const s = getSetting(this.db, 'app', {});
    return {
      engine: { ...DEFAULT, ...(s.engine || {}), weights: { ...DEFAULT.weights, ...(s.engine?.weights || {}) } },
      sources: { binance: true, twelvedata: true, ...(s.sources || {}) },
      ai: { enabled: true, ...(s.ai || {}) },
      candleTtlSec: s.candleTtlSec ?? 3, tdTtlSec: s.tdTtlSec ?? 30,
    };
  }
  sourceState(src) {
    const p = this.providers[src];
    if (src === 'otc' || !p) return 'no_data';
    if (!this.settings().sources[src]) return 'source_off';
    if (p.configured === false) return 'not_configured';
    return 'ready';
  }
  #mark(src, err) {
    const h = (this.health[src] ??= { ok: 0, fail: 0, lastOk: null, lastError: null, lastErrorAt: null });
    if (err) { h.fail++; h.lastError = err.message; h.lastErrorAt = this.now(); logEvent(this.db, 'error', src, err.message); }
    else { h.ok++; h.lastOk = this.now(); }
  }
  pub(r) { return { id: r.id, symbol: r.symbol, name: r.name, category: r.category, mode: r.mode, source: r.source, enabled: !!r.enabled, status: this.sourceState(r.source) }; }
  instrument(id, { onlyEnabled = true } = {}) {
    const r = this.db.prepare('SELECT * FROM instruments WHERE id=?').get(id);
    if (!r || (onlyEnabled && !r.enabled)) throw new ServiceError('not_found', 'Instrument not found', 404);
    return r;
  }
  list({ cat, q, mode, all = false } = {}) {
    let rows = this.db.prepare('SELECT * FROM instruments ORDER BY sort, name').all();
    if (!all) rows = rows.filter((r) => r.enabled);
    if (cat) rows = rows.filter((r) => r.category === cat);
    if (mode) rows = rows.filter((r) => r.mode === mode);
    if (q) { const s = q.toLowerCase(); rows = rows.filter((r) => r.name.toLowerCase().includes(s) || r.symbol.toLowerCase().includes(s)); }
    return rows.map((r) => this.pub(r));
  }
  async candles(inst, hz) {
    if (!HORIZONS.includes(hz)) throw new ServiceError('bad_horizon', 'Unsupported horizon', 400);
    const st = this.sourceState(inst.source);
    if (st !== 'ready') throw new ServiceError(st, `No reliable data: ${st}`);
    const iv = IVS[inst.source]?.[hz];
    if (!iv) throw new ServiceError('interval_unsupported', 'This source has no candles frequent enough for this horizon');
    const key = `${inst.source}:${inst.symbol}:${iv}`, cfg = this.settings();
    let c = this.cache.get(key);
    if (!c) {
      try { c = await this.providers[inst.source].getCandles(inst.symbol, iv, 150); }
      catch (e) { this.#mark(inst.source, e); throw new ServiceError('provider_error', e.message, 502); }
      this.#mark(inst.source);
      this.cache.set(key, c, (inst.source === 'binance' ? cfg.candleTtlSec : cfg.tdTtlSec) * 1000);
    }
    return { candles: c, interval: iv };
  }
  async chart(id, hz) {
    const inst = this.instrument(id), { candles, interval } = await this.candles(inst, hz), cl = candles.map((x) => x.c);
    return { interval, source: inst.source, updatedAt: candles.at(-1)?.closeTime ?? null, candles, ema9: ema(cl, 9), ema21: ema(cl, 21), ema50: ema(cl, 50) };
  }
  async createSignal(id, hz, language = 'English') {
    const inst = this.instrument(id), cfg = this.settings();
    const { candles, interval } = await this.candles(inst, hz);
    const r = analyze(candles, { intervalMs: IVMS[interval], now: this.now(), horizon: hz }, cfg.engine);
    if (r.decision === 'UNAVAILABLE') return { decision: 'UNAVAILABLE', reasons: r.reasons };
    let ai = null, dir = r.decision, strength = r.strength, conflict = false;
    if (cfg.ai.enabled) {
      ai = await this.ai({ timeoutMs: 4000 }, { name: inst.name, horizon: hz, interval, candles, result: r, language });
      if (ai) {
        if (ai.verdict === dir) strength = Math.min(3, strength + 1);
        else { conflict = true; strength = 1; if (ai.confidence === 'high' && r.edge < cfg.engine.medium) dir = ai.verdict; }
      }
    }
    const t = this.now(), exp = t + hz * 1000;
    const info = this.db.prepare('INSERT INTO signals(instrument_id,direction,created_at,horizon,price0,expires_at,strength,bull,bear,reasons,ai) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(id, dir, t, hz, r.price, exp, strength, r.bull, r.bear, JSON.stringify(r.reasons), ai ? JSON.stringify(ai) : null);
    return { id: Number(info.lastInsertRowid), decision: dir, strength, conflict, bull: r.bull, bear: r.bear, reasons: r.reasons, ai, price: r.price, createdAt: t, expiresAt: exp, horizon: hz };
  }
  async verifyDue() {
    const now = this.now(), rows = this.db.prepare("SELECT s.*, i.symbol, i.source FROM signals s LEFT JOIN instruments i ON i.id=s.instrument_id WHERE s.status='pending' AND s.expires_at<=? LIMIT 50").all(now - 2000);
    let done = 0;
    for (const s of rows) {
      let p1 = null;
      try { p1 = await this.providers[s.source]?.priceAt?.(s.symbol, s.expires_at) ?? null; } catch (e) { this.#mark(s.source, e); }
      if (p1 == null && now < s.expires_at + 10 * 60000) continue; // ще немає даних — спробуємо пізніше
      const res = p1 == null || p1 === s.price0 ? 'undetermined' : ((p1 > s.price0) === (s.direction === 'CALL') ? 'correct' : 'wrong');
      this.db.prepare("UPDATE signals SET price1=?, result=?, status='checked' WHERE id=?").run(p1, res, s.id); done++;
    }
    return done;
  }
  signals({ id, limit = 20 } = {}) {
    const q = id ? this.db.prepare('SELECT * FROM signals WHERE instrument_id=? ORDER BY id DESC LIMIT ?').all(id, limit) : this.db.prepare('SELECT * FROM signals ORDER BY id DESC LIMIT ?').all(limit);
    return q.map((s) => ({ id: s.id, instrumentId: s.instrument_id, direction: s.direction, createdAt: s.created_at, horizon: s.horizon, price0: s.price0, price1: s.price1, result: s.result, status: s.status, strength: s.strength, expiresAt: s.expires_at }));
  }
  stats() {
    const rows = this.db.prepare('SELECT instrument_id i, direction d, horizon h, result r, status s, created_at c, expires_at e FROM signals').all();
    const agg = () => ({ total: 0, checked: 0, correct: 0, wrong: 0, undetermined: 0 });
    const out = { ...agg(), call: 0, put: 0, pending: 0, byInstrument: {}, byHorizon: {}, startedAt: null, lastCheckedAt: null };
    const add = (o, x) => { o.total++; if (x.s === 'checked') { o.checked++; o[x.r]++; } };
    for (const x of rows) {
      add(out, x); x.d === 'CALL' ? out.call++ : out.put++; if (x.s === 'pending') out.pending++;
      add((out.byInstrument[x.i] ??= agg()), x); add((out.byHorizon[x.h] ??= agg()), x);
      out.startedAt = Math.min(out.startedAt ?? x.c, x.c); if (x.s === 'checked') out.lastCheckedAt = Math.max(out.lastCheckedAt ?? x.e, x.e);
    }
    const rate = (o) => { const n = o.correct + o.wrong; if (!n) return null; const w = wilson(o.correct, n); return { p: w.p, lo: w.lo, hi: w.hi, n }; };
    out.rate = rate(out);
    for (const o of [...Object.values(out.byInstrument), ...Object.values(out.byHorizon)]) o.rate = rate(o);
    return out;
  }
  status() {
    const cfg = this.settings();
    const sources = {};
    for (const n of ['binance', 'twelvedata']) sources[n] = { enabled: cfg.sources[n], configured: this.providers[n]?.configured !== false, health: this.health[n] || null };
    return { sources, errors: this.db.prepare('SELECT ts,source,message FROM event_log WHERE level=? ORDER BY id DESC LIMIT 30').all('error') };
  }
}
