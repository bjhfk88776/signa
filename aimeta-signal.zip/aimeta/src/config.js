// Всі пороги й ваги тут — змінюються без переписування рушія.
export const DEFAULT = {
  minCandles: 60,       // менше свічок -> UNAVAILABLE
  staleIntervals: 3,    // свічка старша за N інтервалів -> UNAVAILABLE
  minVolatility: 2e-5,  // ATR / ціна; нижче -> позначка "низька волатильність"
  strong: 5,            // edge >= strong -> сильний сигнал
  medium: 3,            // edge >= medium -> середній, інакше слабкий
  weights: { ema: 2, ema2: 1.5, rsi: 1, macd: 1.5, momentum: 1, levels: 1 },
  // Профілі за горизонтом прогнозу (секунди): періоди швидкої/середньої/повільної EMA, період RSI, вікно імпульсу (у свічках)
  profiles: {
    30: { ema: [3, 8, 13], rsi: 7, mom: 3 },
    60: { ema: [5, 13, 26], rsi: 9, mom: 4 },
    180: { ema: [9, 21, 50], rsi: 14, mom: 5 },
    300: { ema: [9, 21, 50], rsi: 14, mom: 8 },
    default: { ema: [9, 21, 50], rsi: 14, mom: 5 },
  },
  rsiHigh: 75, rsiLow: 25, rsiBull: 55, rsiBear: 45,
};
export const PAYOUT = 0.85; // виплата за вірний прогноз (для розрахунку беззбитковості)
