import crypto from 'node:crypto';

/** Перевірка підпису Telegram Mini App initData (https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app). */
export function verifyInitData(initData, botToken, { maxAgeSec = 86400, now = Date.now() } = {}) {
  if (!initData || !botToken || initData.length > 4096) return null;
  const p = new URLSearchParams(initData), hash = p.get('hash');
  if (!hash || !/^[0-9a-f]{64}$/.test(hash)) return null;
  p.delete('hash');
  const check = [...p.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const calc = crypto.createHmac('sha256', secret).update(check).digest('hex');
  if (!crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(hash))) return null;
  const age = now / 1000 - Number(p.get('auth_date'));
  if (!Number.isFinite(age) || age > maxAgeSec || age < -300) return null;
  try { const user = JSON.parse(p.get('user') || 'null'); return user?.id ? { user } : null; } catch { return null; }
}
