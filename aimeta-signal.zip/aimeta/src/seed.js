// Каталог Pocket Option. Редагується в адмін-панелі (в т.ч. масовий імпорт) без правок коду.
// OTC — власний потік котирувань платформи, публічного джерела немає: сигнали для OTC не формуються.
const OTC_FX = 'AED/CNY AUD/CAD AUD/CHF AUD/NZD BHD/CNY CAD/CHF CHF/JPY EUR/CHF EUR/GBP EUR/HUF EUR/JPY EUR/TRY EUR/USD GBP/USD KES/USD NGN/USD SAR/CNY UAH/USD USD/BDT USD/CNH USD/COP USD/EGP USD/INR USD/JPY USD/MXN USD/THB USD/VND YER/USD ZAR/USD AUD/JPY USD/BRL AUD/USD CAD/JPY USD/DZD OMR/CNY QAR/CNY USD/PKR USD/CHF LBP/USD USD/CLP NZD/USD USD/MYR GBP/AUD USD/SGD NZD/JPY MAD/USD EUR/NZD GBP/JPY JOD/CNY USD/PHP CHF/NOK USD/IDR USD/CAD TND/USD USD/ARS'.split(' ');
const LIVE_FX = 'EUR/JPY GBP/JPY EUR/CAD AUD/CHF AUD/JPY AUD/USD CAD/CHF CAD/JPY CHF/JPY EUR/CHF EUR/GBP EUR/USD GBP/AUD GBP/CAD GBP/CHF GBP/USD USD/CAD USD/CHF USD/JPY AUD/CAD EUR/AUD'.split(' ');
const OTC_CR = [['Bitcoin', 'BTC'], ['Litecoin', 'LTC'], ['TRON', 'TRX'], ['Polygon', 'MATIC'], ['Dogecoin', 'DOGE'], ['Cardano', 'ADA'], ['Ethereum', 'ETH'], ['Toncoin', 'TON'], ['Chainlink', 'LINK'], ['BNB', 'BNB'], ['Solana', 'SOL'], ['Polkadot', 'DOT'], ['Avalanche', 'AVAX'], ['Bitcoin ETF', 'BTCETF']];
const LIVE_CR = [['Dash', 'DASHUSDT', 'binance'], ['BCH/EUR', 'BCH/EUR', 'twelvedata'], ['BCH/GBP', 'BCH/GBP', 'twelvedata'], ['BCH/JPY', 'BCH/JPY', 'twelvedata'], ['Chainlink', 'LINKUSDT', 'binance'], ['Ethereum', 'ETHUSDT', 'binance'], ['BTC/GBP', 'BTC/GBP', 'twelvedata'], ['BTC/JPY', 'BTC/JPY', 'twelvedata']];
// [назва, символ Twelve Data]; символи нафти й газу перевірте у вашому тарифі Twelve Data
const CM = [['Brent Oil', 'BRENT/USD'], ['WTI Crude Oil', 'WTI/USD'], ['Silver', 'XAG/USD'], ['Gold', 'XAU/USD'], ['Natural Gas', 'NG/USD'], ['Palladium spot', 'XPD/USD'], ['Platinum spot', 'XPT/USD']];
const CM_LIVE_EXTRA = [['XAG/EUR', 'XAG/EUR'], ['XAU/EUR', 'XAU/EUR']];
// Лишається з попередньої версії: список акцій від вас ще не надійшов
const EQ = 'AAPL TSLA NVDA MSFT AMZN META GOOGL NFLX AMD INTC BABA BA DIS JPM V MA KO PEP MCD NKE WMT XOM CVX PFE JNJ PG CSCO ORCL IBM ADBE CRM PYPL UBER COIN SHOP QCOM T'.split(' ');

export const makeId = (category, symbol, mode) => `${category}:${symbol}${mode === 'otc' ? ':otc' : ''}`;

export function seed(db) {
  if (db.prepare('SELECT COUNT(*) n FROM instruments').get().n > 0) return;
  const ins = db.prepare('INSERT OR IGNORE INTO instruments(id,symbol,name,category,source,mode,enabled,sort) VALUES(?,?,?,?,?,?,1,?)');
  let i = 0;
  const add = (cat, mode, name, symbol, source) => ins.run(makeId(cat, symbol, mode), symbol, mode === 'otc' ? `${name} OTC` : name, cat, mode === 'otc' ? 'otc' : source, mode, i++);
  for (const s of OTC_FX) add('fx', 'otc', s, s);
  for (const s of LIVE_FX) add('fx', 'live', s, s, 'twelvedata');
  for (const [n, s] of OTC_CR) add('cr', 'otc', n, s);
  for (const [n, s, src] of LIVE_CR) add('cr', 'live', n, s, src);
  for (const [n, s] of CM) add('cm', 'otc', n, s);
  for (const [n, s] of [...CM, ...CM_LIVE_EXTRA]) add('cm', 'live', n, s, 'twelvedata');
  for (const s of EQ) add('eq', 'live', s, s, 'twelvedata');
}
