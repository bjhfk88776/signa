// Мінімальний Telegram-бот без залежностей: відкриває Mini App кнопкою та кнопкою меню.
const TEXT = {
  ru: ['Открой мини-приложение, выбери инструмент и время. Сигнал — оценка алгоритма, а не гарантия прибыли.', 'Открыть'],
  uk: ['Відкрий міні-застосунок, обери інструмент і час. Сигнал — оцінка алгоритму, а не гарантія прибутку.', 'Відкрити'],
  en: ['Open the mini app, pick an instrument and time. A signal is an algorithm estimate, not a guarantee of profit.', 'Open'],
};
export function createBot({ token, url, fetchImpl = fetch }) {
  if (!token || !/^https:\/\//.test(url || '')) throw new Error('BOT_TOKEN and an https WEBAPP_URL are required');
  const call = async (method, body = {}, timeoutMs = 15000) => {
    const r = await fetchImpl(`https://api.telegram.org/bot${token}/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(timeoutMs) });
    const j = await r.json();
    if (!j.ok) throw new Error(`Telegram ${method}: ${j.description || r.status}`);
    return j.result;
  };
  async function handle(update) {
    const m = update.message;
    if (!m?.text || !m.text.startsWith('/start')) return false;
    const lang = ['ru', 'uk', 'en'].includes((m.from?.language_code || '').slice(0, 2)) ? m.from.language_code.slice(0, 2) : 'en';
    const [text, btn] = TEXT[lang];
    await call('sendMessage', { chat_id: m.chat.id, text, reply_markup: { inline_keyboard: [[{ text: btn, web_app: { url } }]] } });
    return true;
  }
  async function run(log = console) {
    await call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'AIMETA SIGNAL', web_app: { url } } });
    let offset = 0;
    for (;;) {
      try {
        const ups = await call('getUpdates', { offset, timeout: 50, allowed_updates: ['message'] }, 65000);
        for (const u of ups) { offset = u.update_id + 1; await handle(u).catch((e) => log.error(e.message)); }
      } catch (e) { log.error(e.message); await new Promise((r) => setTimeout(r, 5000)); }
    }
  }
  return { handle, run, call };
}
