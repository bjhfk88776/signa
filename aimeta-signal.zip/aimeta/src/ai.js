/** Необов'язковий ШІ-шар (Claude API). Ключ лише на сервері: ANTHROPIC_API_KEY. */
export async function askAI({ apiKey = process.env.ANTHROPIC_API_KEY, model = process.env.AI_MODEL || 'claude-sonnet-5-5', fetchImpl = fetch, timeoutMs = 20000 } = {}, ctx) {
  if (!apiKey) return null;
  const f = (x) => (x == null || !Number.isFinite(x) ? null : +x.toPrecision(6));
  const cl = ctx.candles.map((k) => k.c), ch = (n) => f((cl.at(-1) / cl.at(-n) - 1) * 100), r = ctx.result;
  const prompt = `You are a senior short-term market analyst. Instrument ${ctx.name}, forecast horizon ${ctx.horizon}s, candle ${ctx.interval}.
Last 60 closes: ${JSON.stringify(cl.slice(-60).map(f))}
Last 20 highs: ${JSON.stringify(ctx.candles.slice(-20).map((k) => f(k.h)))}
Last 20 lows: ${JSON.stringify(ctx.candles.slice(-20).map((k) => f(k.l)))}
Change % over last 5/15/40/100 candles: ${ch(5)}, ${ch(15)}, ${ch(40)}, ${ch(100)}.
fast EMA ${f(r.ema9)}, medium EMA ${f(r.ema21)}, slow EMA ${f(r.ema50)}, RSI14 ${f(r.rsi)}, MACD histogram ${f(r.macdHist)}, ATR% ${f((r.atr / r.price) * 100)}.
Rule engine leans ${r.decision} (bull ${r.bull}, bear ${r.bear}).
Assess trend structure on several windows, momentum and exhaustion, support/resistance, volatility, and whether the lean matches the raw candles. Choose exactly CALL (higher after ${ctx.horizon}s) or PUT (lower). Never state a probability of profit. Write text in ${ctx.language}.
Return only JSON: {"verdict":"CALL|PUT","confidence":"low|medium|high","factors":["3-4 short factors"],"summary":"max 2 sentences","risks":"max 1 sentence"}`;
  try {
    const res = await fetchImpl('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: AbortSignal.timeout(timeoutMs),
      headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model, max_tokens: 600, messages: [{ role: 'user', content: prompt }] }),
    });
    if (!res.ok) return null;
    const txt = (await res.json()).content?.find((b) => b.type === 'text')?.text || '';
    const a = JSON.parse(txt.slice(txt.indexOf('{'), txt.lastIndexOf('}') + 1));
    if (!['CALL', 'PUT'].includes(a.verdict)) return null;
    const s = (x, n) => String(x ?? '').slice(0, n);
    return { verdict: a.verdict, confidence: ['low', 'medium', 'high'].includes(a.confidence) ? a.confidence : 'low',
      factors: Array.isArray(a.factors) ? a.factors.slice(0, 4).map((x) => s(x, 160)) : [], summary: s(a.summary, 400), risks: s(a.risks, 200) };
  } catch { return null; }
}
