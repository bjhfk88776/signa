import crypto from 'node:crypto';

export function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `scrypt$${salt}$${crypto.scryptSync(pw, salt, 64).toString('hex')}`;
}
const DUMMY = hashPassword('dummy-password-for-timing');
export function verifyPassword(pw, stored) {
  const [alg, salt, hash] = String(stored || DUMMY).split('$');
  if (alg !== 'scrypt') return false;
  const a = Buffer.from(hash, 'hex'), b = crypto.scryptSync(String(pw), salt, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b) && stored != null;
}
export function createSession(db, username, now = Date.now(), ttlMs = 8 * 3600e3) {
  const token = crypto.randomBytes(32).toString('hex'), csrf = crypto.randomBytes(16).toString('hex');
  db.prepare('DELETE FROM sessions WHERE expires<?').run(now);
  db.prepare('INSERT INTO sessions(token,username,csrf,expires) VALUES(?,?,?,?)').run(token, username, csrf, now + ttlMs);
  return { token, csrf, maxAge: ttlMs / 1000 };
}
export const getSession = (db, token, now = Date.now()) => (token ? db.prepare('SELECT * FROM sessions WHERE token=? AND expires>?').get(token, now) : undefined);
export const destroySession = (db, token) => db.prepare('DELETE FROM sessions WHERE token=?').run(token);
export const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
