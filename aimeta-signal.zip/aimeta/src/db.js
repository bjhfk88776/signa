import { DatabaseSync } from 'node:sqlite';

export function openDb(file = ':memory:') {
  const db = new DatabaseSync(file);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
  CREATE TABLE IF NOT EXISTS instruments(id TEXT PRIMARY KEY, symbol TEXT NOT NULL, name TEXT NOT NULL, category TEXT NOT NULL, source TEXT NOT NULL, mode TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY AUTOINCREMENT, instrument_id TEXT NOT NULL, direction TEXT NOT NULL, created_at INTEGER NOT NULL, horizon INTEGER NOT NULL, price0 REAL NOT NULL, expires_at INTEGER NOT NULL, price1 REAL, result TEXT, status TEXT NOT NULL DEFAULT 'pending', strength INTEGER, bull REAL, bear REAL, reasons TEXT, ai TEXT);
  CREATE INDEX IF NOT EXISTS sig_pending ON signals(status, expires_at);
  CREATE INDEX IF NOT EXISTS sig_inst ON signals(instrument_id, created_at);
  CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS admins(username TEXT PRIMARY KEY, hash TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, username TEXT NOT NULL, csrf TEXT NOT NULL, expires INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS texts(key TEXT NOT NULL, lang TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(key, lang));
  CREATE TABLE IF NOT EXISTS event_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, level TEXT NOT NULL, source TEXT, message TEXT NOT NULL);`);
  return db;
}
export const getSetting = (db, k, d) => { const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return r ? JSON.parse(r.value) : d; };
export const setSetting = (db, k, v) => db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, JSON.stringify(v));
export const logEvent = (db, level, source, message) => db.prepare('INSERT INTO event_log(ts,level,source,message) VALUES(?,?,?,?)').run(Date.now(), level, source, String(message).slice(0, 300));
