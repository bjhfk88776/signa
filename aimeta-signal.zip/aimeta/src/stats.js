// 95% довірчий інтервал Вілсона для частки правильних прогнозів
export function wilson(k, n, z = 1.96) {
  if (n === 0) return { p: NaN, lo: NaN, hi: NaN };
  const p = k / n, d = 1 + (z * z) / n;
  const c = (p + (z * z) / (2 * n)) / d;
  const h = (z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n))) / d;
  return { p, lo: c - h, hi: c + h };
}
export const breakEven = (payout) => 1 / (1 + payout);
