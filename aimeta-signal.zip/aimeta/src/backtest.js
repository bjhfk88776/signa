import { BinanceProvider } from './providers/binance.js';
import { analyze } from './engine.js';
import { wilson, breakEven } from './stats.js';
import { PAYOUT } from './config.js';

// Використання: node src/backtest.js BTCUSDT 1m 10000 3
//  -> символ, інтервал свічки, кількість свічок, горизонт у свічках
const [, , symbol = 'BTCUSDT', interval = '1m', n = '10000', hz = '3'] = process.argv;
const H = Number(hz), WINDOW = 120;

function run(cs, from, to) {
  const b = { all: [0, 0], 1: [0, 0], 2: [0, 0], 3: [0, 0] };
  for (let i = Math.max(from, WINDOW); i < to - H; i++) {
    const r = analyze(cs.slice(i - WINDOW + 1, i + 1), { horizon: H * 60 }); // 1-хв свічки: H свічок = H*60 с
    if (r.decision === 'UNAVAILABLE') continue;
    const d = cs[i + H].c - cs[i].c;
    if (d === 0) continue; // нічия не рахуємо
    const win = (d > 0) === (r.decision === 'CALL') ? 1 : 0;
    for (const k of ['all', r.strength]) { b[k][0] += win; b[k][1]++; }
  }
  return b;
}
const fmt = (k, nn) => {
  if (!nn) return '—';
  const w = wilson(k, nn);
  return `${(w.p * 100).toFixed(1)}%  (95% ДІ ${(w.lo * 100).toFixed(1)}–${(w.hi * 100).toFixed(1)}%, n=${nn})`;
};

const cs = await new BinanceProvider().getCandles(symbol, interval, Number(n));
const cut = Math.floor(cs.length * 0.7);
console.log(`${symbol} ${interval}, свічок: ${cs.length}, горизонт: ${H} св.`);
console.log(`Беззбитковість при виплаті ${PAYOUT * 100}%: ${(breakEven(PAYOUT) * 100).toFixed(1)}%\n`);
for (const [label, a, z] of [['Перші 70% (на цих даних можна підбирати налаштування)', 0, cut], ['Останні 30% (НЕ чіпати при підборі — чесна перевірка)', cut, cs.length]]) {
  const b = run(cs, a, z);
  console.log(label);
  console.log('  усі:      ', fmt(...b.all));
  for (const s of [1, 2, 3]) console.log(`  сила ${s}:   `, fmt(...b[s]));
}
const t = run(cs, cut, cs.length).all, w = wilson(...t);
console.log('\nВисновок:', w.lo > breakEven(PAYOUT)
  ? 'на тестовому відрізку нижня межа ДІ вища за беззбитковість (потрібна перевірка на інших ринках і періодах).'
  : 'переваги над беззбитковістю на тестовому відрізку НЕ доведено.');
