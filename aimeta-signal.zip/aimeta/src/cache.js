export class TTLCache {
  constructor(now = Date.now) { this.m = new Map(); this.now = now; }
  get(k) { const e = this.m.get(k); if (!e) return undefined; if (e.x < this.now()) { this.m.delete(k); return undefined; } return e.v; }
  set(k, v, ttlMs) { this.m.set(k, { v, x: this.now() + ttlMs }); if (this.m.size > 2000) this.m.delete(this.m.keys().next().value); }
}
/** Ковзне вікно: не більше max запитів за perMs. */
export class RateLimiter {
  constructor(max, perMs, now = Date.now) { Object.assign(this, { max, perMs, now, hits: [] }); }
  tryTake() { const t = this.now(); this.hits = this.hits.filter((x) => t - x < this.perMs); if (this.hits.length >= this.max) return false; this.hits.push(t); return true; }
}
