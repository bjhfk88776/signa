export const ema = (a, p) => {
  const k = 2 / (p + 1), o = [a[0]];
  for (let i = 1; i < a.length; i++) o.push(a[i] * k + o[i - 1] * (1 - k));
  return o;
};

// RSI за Вайлдером
export function rsi(c, p = 14) {
  if (c.length <= p) return null;
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = c[i] - c[i - 1]; d > 0 ? (g += d) : (l -= d); }
  g /= p; l /= p;
  for (let i = p + 1; i < c.length; i++) {
    const d = c[i] - c[i - 1];
    g = (g * (p - 1) + Math.max(d, 0)) / p;
    l = (l * (p - 1) + Math.max(-d, 0)) / p;
  }
  return l === 0 ? 100 : 100 - 100 / (1 + g / l);
}

const trueRange = (cs, i) =>
  Math.max(cs[i].h - cs[i].l, Math.abs(cs[i].h - cs[i - 1].c), Math.abs(cs[i].l - cs[i - 1].c));

export function atr(cs, p = 14) {
  if (cs.length <= p) return null;
  let a = 0;
  for (let i = 1; i <= p; i++) a += trueRange(cs, i);
  a /= p;
  for (let i = p + 1; i < cs.length; i++) a = (a * (p - 1) + trueRange(cs, i)) / p;
  return a;
}

export function macd(c, f = 12, s = 26, g = 9) {
  const a = ema(c, f), b = ema(c, s);
  const line = a.map((x, i) => x - b[i]);
  const signal = ema(line, g);
  return { line, signal, hist: line.map((x, i) => x - signal[i]) };
}

// Локальні екстремуми: опір — максимум вище 2 сусідів з кожного боку, підтримка — мінімум
export function levels(cs, k = 2) {
  const res = [], sup = [];
  for (let i = k; i < cs.length - k; i++) {
    let hi = true, lo = true;
    for (let d = 1; d <= k; d++) {
      if (!(cs[i].h > cs[i - d].h && cs[i].h > cs[i + d].h)) hi = false;
      if (!(cs[i].l < cs[i - d].l && cs[i].l < cs[i + d].l)) lo = false;
    }
    if (hi) res.push(cs[i].h);
    if (lo) sup.push(cs[i].l);
  }
  return { resistance: res, support: sup };
}
