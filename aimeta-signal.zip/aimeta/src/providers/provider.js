/** Абстракція джерела даних: можна замінити Binance на Twelve Data без змін рушія. */
export class MarketDataProvider {
  get name() { return 'abstract'; }
  /** @returns {Promise<Array<{t,o,h,l,c,v,closeTime}>>} закриті свічки, від старої до нової */
  async getCandles(symbol, interval, limit) { throw new Error('getCandles() not implemented'); }
}
