import { MarketDataProvider } from './provider.js';

const MS = { '1s': 1e3, '1m': 60e3, '3m': 180e3, '5m': 300e3, '15m': 900e3, '1h': 3600e3 };

export class BinanceProvider extends MarketDataProvider {
  // data-api.binance.vision — публічні ринкові дані без ключа; змініть BINANCE_BASE за потреби
  constructor({ base = process.env.BINANCE_BASE || 'https://data-api.binance.vision', fetchImpl = fetch, timeoutMs = 10000, pauseMs = 150 } = {}) {
    super(); Object.assign(this, { base, fetchImpl, timeoutMs, pauseMs });
  }
  get name() { return 'binance'; }

  async #page(symbol, interval, limit, endTime) {
    const u = new URL('/api/v3/klines', this.base);
    u.search = new URLSearchParams({ symbol, interval, limit: String(limit), ...(endTime ? { endTime: String(endTime) } : {}) });
    let res;
    try { res = await this.fetchImpl(u, { signal: AbortSignal.timeout(this.timeoutMs) }); }
    catch (e) { throw new Error(`Binance: network/timeout error (${e.name})`); }
    if (res.status === 429 || res.status === 418) throw new Error('Binance: rate limit hit, slow down');
    if (res.status === 451) throw new Error('Binance: region blocked (451), set BINANCE_BASE');
    if (!res.ok) throw new Error(`Binance: HTTP ${res.status}`);
    const rows = await res.json();
    if (!Array.isArray(rows)) throw new Error('Binance: unexpected response');
    return rows.map((k) => ({ t: k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5], closeTime: k[6] }));
  }

  /** Ціна (open) першої свічки, що починається в момент ts або одразу після нього; null якщо ще немає. */
  async priceAt(symbol, ts) {
    const u = new URL('/api/v3/klines', this.base);
    u.search = new URLSearchParams({ symbol, interval: '1s', startTime: String(ts), limit: '1' });
    const res = await this.fetchImpl(u, { signal: AbortSignal.timeout(this.timeoutMs) });
    if (!res.ok) throw new Error(`Binance: HTTP ${res.status}`);
    const rows = await res.json();
    if (!rows.length || Math.abs(rows[0][0] - ts) > 5000) return null;
    return +rows[0][1];
  }

  async getCandles(symbol, interval = '1m', limit = 500) {
    if (!MS[interval]) throw new Error(`Unsupported interval ${interval}`);
    let out = [], end = null;
    while (out.length < limit) {
      const page = await this.#page(symbol, interval, Math.min(1000, limit - out.length), end);
      if (!page.length) break;
      out = page.concat(out);
      end = page[0].t - 1;
      if (page.length < 2) break;
      await new Promise((r) => setTimeout(r, this.pauseMs));
    }
    const now = Date.now();
    return out.filter((c) => c.closeTime < now); // лише закриті свічки
  }
}
