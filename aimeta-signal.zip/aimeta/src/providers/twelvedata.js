import { MarketDataProvider } from './provider.js';
import { RateLimiter } from '../cache.js';

const IV = { '1m': ['1min', 60e3], '5m': ['5min', 300e3], '15m': ['15min', 900e3] };

/** Twelve Data: валюти й акції. Мінімальна свічка — 1 хвилина, тому 30-секундний аналіз недоступний. */
export class TwelveDataProvider extends MarketDataProvider {
  constructor({ apiKey = process.env.TWELVEDATA_API_KEY, fetchImpl = fetch, timeoutMs = 10000, perMinute = Number(process.env.TWELVEDATA_PER_MINUTE) || 8, base = 'https://api.twelvedata.com' } = {}) {
    super(); Object.assign(this, { apiKey, fetchImpl, timeoutMs, base, limiter: new RateLimiter(perMinute, 60000) });
  }
  get name() { return 'twelvedata'; }
  get configured() { return Boolean(this.apiKey); }

  async #series(symbol, interval, size) {
    if (!this.apiKey) throw new Error('Twelve Data: API key is not configured');
    const iv = IV[interval]; if (!iv) throw new Error(`Unsupported interval ${interval}`);
    if (!this.limiter.tryTake()) throw new Error('Twelve Data: local rate limit reached, try again shortly');
    const u = new URL('/time_series', this.base);
    u.search = new URLSearchParams({ symbol, interval: iv[0], outputsize: String(size), order: 'ASC', timezone: 'UTC', apikey: this.apiKey });
    let res;
    try { res = await this.fetchImpl(u, { signal: AbortSignal.timeout(this.timeoutMs) }); }
    catch (e) { throw new Error(`Twelve Data: network/timeout error (${e.name})`); }
    if (res.status === 429) throw new Error('Twelve Data: rate limit hit');
    if (!res.ok) throw new Error(`Twelve Data: HTTP ${res.status}`);
    const j = await res.json();
    if (j.status === 'error' || !Array.isArray(j.values)) throw new Error(`Twelve Data: ${j.code === 429 ? 'rate limit hit' : (j.message || 'bad response')}`.slice(0, 160));
    return j.values.map((v) => { const t = Date.parse(v.datetime.replace(' ', 'T') + 'Z'); return { t, o: +v.open, h: +v.high, l: +v.low, c: +v.close, v: +(v.volume || 0), closeTime: t + iv[1] - 1 }; });
  }
  async getCandles(symbol, interval = '1m', limit = 150) {
    const now = Date.now();
    return (await this.#series(symbol, interval, Math.min(limit, 5000))).filter((c) => c.closeTime < now);
  }
  /** Open першої 1-хвилинної свічки, що починається не раніше ts (точність ±60 с). */
  async priceAt(symbol, ts) {
    const rows = await this.#series(symbol, '1m', 15);
    const c = rows.find((x) => x.t >= ts);
    return c && c.t - ts <= 60000 ? c.o : null;
  }
}
