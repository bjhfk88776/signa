import { ema, rsi, atr, macd, levels } from './indicators.js';
import { DEFAULT } from './config.js';

/**
 * Market Analysis Engine.
 * opts.horizon — горизонт прогнозу в секундах (вибирає профіль індикаторів: швидші для 30 с, повільніші для 5 хв).
 * cs: [{t,o,h,l,c,closeTime?}] від старої до нової (остання — остання ЗАКРИТА свічка).
 * Повертає {decision:'CALL'|'PUT'|'UNAVAILABLE', bull, bear, edge, strength, reasons, ...}.
 * Це оцінка алгоритму, а не ймовірність прибутку.
 */
export function analyze(cs, opts = {}, cfg = DEFAULT) {
  const { intervalMs = 60000, now = null } = opts;
  const out = { decision: 'UNAVAILABLE', bull: 0, bear: 0, edge: 0, strength: 0, reasons: [] };
  if (!Array.isArray(cs) || cs.length < cfg.minCandles) { out.reasons.push('not_enough_candles'); return out; }
  const last = cs[cs.length - 1];
  if (now != null && last.closeTime != null && now - last.closeTime > cfg.staleIntervals * intervalMs) {
    out.reasons.push('stale_data'); return out;
  }
  if (cs.some((x) => ![x.o, x.h, x.l, x.c].every(Number.isFinite))) { out.reasons.push('bad_data'); return out; }

  const c = cs.map((x) => x.c), L = c.length - 1, px = c[L], w = cfg.weights;
  const P = (cfg.profiles || DEFAULT.profiles)[opts.horizon] ?? (cfg.profiles || DEFAULT.profiles).default;
  const e9 = ema(c, P.ema[0]), e21 = ema(c, P.ema[1]), e50 = ema(c, P.ema[2]);
  const r = rsi(c, P.rsi), m = macd(c), a = atr(cs);
  const H = m.hist, R = out.reasons;
  let bull = 0, bear = 0;

  if (e9[L] > e21[L]) { bull += w.ema; R.push('ema9_above_ema21'); } else { bear += w.ema; R.push('ema9_below_ema21'); }
  if (e21[L] > e50[L]) { bull += w.ema2; R.push('ema21_above_ema50'); } else { bear += w.ema2; R.push('ema21_below_ema50'); }

  if (r > cfg.rsiHigh) { bear += w.rsi; R.push('rsi_overbought'); }
  else if (r < cfg.rsiLow) { bull += w.rsi; R.push('rsi_oversold'); }
  else if (r > cfg.rsiBull) { bull += w.rsi; R.push('rsi_bullish'); }
  else if (r < cfg.rsiBear) { bear += w.rsi; R.push('rsi_bearish'); }

  if (H[L] > 0 && H[L] > H[L - 1]) { bull += w.macd; R.push('macd_rising'); }
  else if (H[L] < 0 && H[L] < H[L - 1]) { bear += w.macd; R.push('macd_falling'); }

  const mom = px - c[L - P.mom];
  if (Math.abs(mom) > a * 0.3) { if (mom > 0) { bull += w.momentum; R.push('momentum_up'); } else { bear += w.momentum; R.push('momentum_down'); } }

  const lv = levels(cs.slice(-60));
  const sup = Math.max(-Infinity, ...lv.support.filter((x) => x < px));
  const res = Math.min(Infinity, ...lv.resistance.filter((x) => x > px));
  if (Number.isFinite(sup) && px - sup < a * 0.5) { bull += w.levels; R.push('near_support'); }
  else if (Number.isFinite(res) && res - px < a * 0.5) { bear += w.levels; R.push('near_resistance'); }

  if (a / px < cfg.minVolatility) R.push('low_volatility');
  const diff = bull - bear;
  out.decision = diff > 0 ? 'CALL' : diff < 0 ? 'PUT' : (mom >= 0 ? 'CALL' : 'PUT');
  out.bull = bull; out.bear = bear; out.edge = Math.abs(diff);
  out.strength = out.edge >= cfg.strong ? 3 : out.edge >= cfg.medium ? 2 : 1;
  Object.assign(out, { emaPeriods: P.ema, price: px, rsi: r, atr: a, macdHist: H[L], ema9: e9[L], ema21: e21[L], ema50: e50[L] });
  return out;
}
