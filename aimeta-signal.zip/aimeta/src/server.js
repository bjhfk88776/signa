import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { openDb, getSetting, setSetting } from './db.js';
import { seed, makeId } from './seed.js';
import { SignalService, ServiceError, HORIZONS } from './service.js';
import { BinanceProvider } from './providers/binance.js';
import { TwelveDataProvider } from './providers/twelvedata.js';
import { verifyPassword, createSession, getSession, destroySession, safeEq } from './auth.js';
import { DEFAULT } from './config.js';
import { verifyInitData } from './telegram.js';

const PUB = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const SEC = { 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'", 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' };
const TG_FRAMES = 'https://web.telegram.org https://webk.telegram.org https://webz.telegram.org';
const { 'X-Frame-Options': _xfo, ...SEC_BASE } = SEC;
// Публічні сторінки: Mini App відкривається в WebView/iframe Telegram. Адмінка та API лишаються із забороною фреймів.
const SEC_APP = { ...SEC_BASE, 'Content-Security-Policy': `default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors ${TG_FRAMES}; base-uri 'none'; form-action 'self'` };
const LANGS = { ru: 'Russian', en: 'English', ua: 'Ukrainian' };

class Bucket { // простий ліміт запитів за вікном
  constructor(max, ms) { Object.assign(this, { max, ms }); this.m = new Map(); }
  hit(k, now = Date.now()) { const a = (this.m.get(k) || []).filter((t) => now - t < this.ms); a.push(now); this.m.set(k, a); if (this.m.size > 5000) this.m.clear(); return a.length <= this.max; }
}

export function createApp({ db, service, secureCookie = false, trustProxy = false, botToken = '' }) {
  const rlSignal = new Bucket(15, 60e3), rlAll = new Bucket(300, 60e3), rlLogin = new Bucket(5, 15 * 60e3);
  const send = (res, code, obj, extra = {}) => { const b = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SEC, ...extra }); res.end(b); };
  const body = (req, limit = 32768) => new Promise((ok, no) => {
    let n = 0; const ch = [];
    let over = false;
    req.on('data', (c) => { n += c.length; if (over) return; if (n > limit) { over = true; ch.length = 0; no(new ServiceError('too_large', 'Body too large', 413)); } else ch.push(c); });
    req.on('end', () => { if (over) return; try { ok(ch.length ? JSON.parse(Buffer.concat(ch).toString()) : {}); } catch { no(new ServiceError('bad_json', 'Invalid JSON', 400)); } });
    req.on('error', no);
  });
  const ip = (req) => (trustProxy && req.headers['x-forwarded-for']?.split(',')[0].trim()) || req.socket.remoteAddress || '?';
  const rateKey = (req) => { const tg = verifyInitData(req.headers['x-telegram-init-data'], botToken); return tg ? 'tg:' + tg.user.id : ip(req); };
  const cookie = (req, n) => (req.headers.cookie || '').split(';').map((x) => x.trim().split('=')).find((x) => x[0] === n)?.[1];
  const num = (v, lo, hi, name) => { if (typeof v !== 'number' || !Number.isFinite(v) || v < lo || v > hi) throw new ServiceError('bad_value', `${name}: ${lo}..${hi}`, 400); return v; };
  const str = (v, max, name, re) => { if (typeof v !== 'string' || !v.trim() || v.length > max || (re && !re.test(v))) throw new ServiceError('bad_value', `${name}: invalid`, 400); return v.trim(); };

  async function admin(req, res, u, m) {
    if (u.pathname === '/api/admin/login' && m === 'POST') {
      const b = await body(req), name = String(b.username ?? '').slice(0, 64), key = ip(req) + '|' + name;
      if (!rlLogin.hit(key)) return send(res, 429, { error: 'too_many', message: 'Too many attempts, try later' });
      const row = db.prepare('SELECT * FROM admins WHERE username=?').get(name);
      if (!verifyPassword(b.password ?? '', row?.hash)) return send(res, 401, { error: 'bad_credentials', message: 'Invalid credentials' });
      rlLogin.m.delete(key);
      const s = createSession(db, name);
      return send(res, 200, { username: name, csrf: s.csrf }, { 'Set-Cookie': `sid=${s.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${s.maxAge}${secureCookie ? '; Secure' : ''}` });
    }
    const sess = getSession(db, cookie(req, 'sid'));
    if (!sess) return send(res, 401, { error: 'unauthorized', message: 'Login required' });
    if (m !== 'GET' && !safeEq(req.headers['x-csrf-token'] ?? '', sess.csrf)) return send(res, 403, { error: 'csrf', message: 'Bad CSRF token' });
    const p = u.pathname;
    if (p === '/api/admin/me') return send(res, 200, { username: sess.username, csrf: sess.csrf });
    if (p === '/api/admin/logout' && m === 'POST') { destroySession(db, sess.token); return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' }); }
    if (p === '/api/admin/status') return send(res, 200, { ...service.status(), ai: { configured: Boolean(process.env.ANTHROPIC_API_KEY) }, counts: { instruments: db.prepare('SELECT COUNT(*) n FROM instruments').get().n, signals: db.prepare('SELECT COUNT(*) n FROM signals').get().n } });
    if (p === '/api/admin/settings') {
      if (m === 'GET') return send(res, 200, service.settings());
      if (m === 'PUT') {
        const b = await body(req), cur = getSetting(db, 'app', {}), e = b.engine || {}, E = {};
        const lim = { minCandles: [60, 150], staleIntervals: [1, 20], minVolatility: [0, 0.01], strong: [1, 20], medium: [1, 20], rsiHigh: [50, 100], rsiLow: [0, 50], rsiBull: [50, 70], rsiBear: [30, 50] };
        for (const [k, [lo, hi]] of Object.entries(lim)) if (k in e) E[k] = num(e[k], lo, hi, k);
        if (e.weights) { E.weights = {}; for (const k of Object.keys(DEFAULT.weights)) if (k in e.weights) E.weights[k] = num(e.weights[k], 0, 10, 'w.' + k); }
        const next = { ...cur, engine: { ...(cur.engine || {}), ...E, weights: { ...(cur.engine?.weights || {}), ...(E.weights || {}) } } };
        if (b.sources) { next.sources = { ...(cur.sources || {}) }; for (const k of ['binance', 'twelvedata']) if (k in b.sources) { if (typeof b.sources[k] !== 'boolean') throw new ServiceError('bad_value', 'sources: boolean', 400); next.sources[k] = b.sources[k]; } }
        if (b.ai && 'enabled' in b.ai) { if (typeof b.ai.enabled !== 'boolean') throw new ServiceError('bad_value', 'ai.enabled: boolean', 400); next.ai = { enabled: b.ai.enabled }; }
        if ('candleTtlSec' in b) next.candleTtlSec = num(b.candleTtlSec, 1, 60, 'candleTtlSec');
        if ('tdTtlSec' in b) next.tdTtlSec = num(b.tdTtlSec, 15, 300, 'tdTtlSec');
        setSetting(db, 'app', next); return send(res, 200, service.settings());
      }
    }
    if (p === '/api/admin/instruments') {
      if (m === 'GET') return send(res, 200, { items: service.list({ all: true }) });
      if (m === 'POST') {
        const b = await body(req), ok = (v, a, n) => { if (!a.includes(v)) throw new ServiceError('bad_value', `${n}: ${a.join('|')}`, 400); return v; };
        const cat = ok(b.category, ['fx', 'cr', 'eq', 'cm'], 'category'), mode = ok(b.mode ?? 'live', ['live', 'otc'], 'mode'), source = mode === 'otc' ? 'otc' : ok(b.source, ['binance', 'twelvedata'], 'source');
        const sym = str(b.symbol, 30, 'symbol', /^[A-Za-z0-9./_-]+$/), name = str(b.name || sym + (mode === 'otc' ? ' OTC' : ''), 40, 'name');
        db.prepare('INSERT OR REPLACE INTO instruments(id,symbol,name,category,source,mode,enabled,sort) VALUES(?,?,?,?,?,?,1,COALESCE((SELECT sort FROM instruments WHERE id=?),9999))').run(makeId(cat, sym, mode), sym, name, cat, source, mode, makeId(cat, sym, mode));
        return send(res, 200, { ok: true });
      }
    }
    if (p === '/api/admin/instruments/bulk' && m === 'POST') { // рядки: category|symbol|source|mode|name?
      const b = await body(req, 131072), lines = String(b.text || '').split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 500);
      const ins = db.prepare('INSERT OR REPLACE INTO instruments(id,symbol,name,category,source,mode,enabled,sort) VALUES(?,?,?,?,?,?,1,9999)'); let added = 0; const bad = [];
      for (const [i, l] of lines.entries()) {
        const [cat, sym, source, mode = 'live', name] = l.split('|').map((x) => x.trim());
        if (!['fx', 'cr', 'eq', 'cm'].includes(cat) || !/^[A-Za-z0-9./_-]{1,30}$/.test(sym || '') || !['binance', 'twelvedata', 'otc'].includes(source) || !['live', 'otc'].includes(mode)) { bad.push(i + 1); continue; }
        ins.run(makeId(cat, sym, mode), sym, (name || sym + (mode === 'otc' ? ' OTC' : '')).slice(0, 40), cat, mode === 'otc' ? 'otc' : source, mode); added++;
      }
      return send(res, 200, { added, badLines: bad });
    }
    const im = p.match(/^\/api\/admin\/instruments\/(.+)$/);
    if (im) {
      const id = decodeURIComponent(im[1]); service.instrument(id, { onlyEnabled: false });
      if (m === 'PUT') { const b = await body(req); if (typeof b.enabled !== 'boolean') throw new ServiceError('bad_value', 'enabled: boolean', 400); db.prepare('UPDATE instruments SET enabled=? WHERE id=?').run(b.enabled ? 1 : 0, id); return send(res, 200, { ok: true }); }
      if (m === 'DELETE') { db.prepare('DELETE FROM instruments WHERE id=?').run(id); return send(res, 200, { ok: true }); }
    }
    if (p === '/api/admin/signals') return send(res, 200, { items: service.signals({ limit: Math.min(Number(u.searchParams.get('limit')) || 100, 500) }) });
    if (p === '/api/admin/texts') {
      if (m === 'GET') return send(res, 200, { items: db.prepare('SELECT * FROM texts ORDER BY key, lang').all() });
      if (m === 'PUT') {
        const b = await body(req), key = str(b.key, 40, 'key', /^[a-z0-9_]+$/), lang = str(b.lang, 2, 'lang', /^(ru|en|ua)$/);
        if (b.value === '') db.prepare('DELETE FROM texts WHERE key=? AND lang=?').run(key, lang);
        else db.prepare('INSERT INTO texts(key,lang,value) VALUES(?,?,?) ON CONFLICT(key,lang) DO UPDATE SET value=excluded.value').run(key, lang, str(b.value, 300, 'value'));
        return send(res, 200, { ok: true });
      }
    }
    return send(res, 404, { error: 'not_found', message: 'Not found' });
  }

  async function api(req, res, u, m) {
    const p = u.pathname;
    if (p === '/api/health') return send(res, 200, { ok: true, time: Date.now() });
    if (p === '/api/config') {
      const rows = service.list(), cats = {};
      for (const r of rows) { const c = (cats[r.category] ??= { total: 0, live: 0, otc: 0, ready: 0 }); c.total++; c[r.mode]++; if (r.status === 'ready') c.ready++; }
      const texts = {}; for (const t of db.prepare('SELECT * FROM texts').all()) (texts[t.key] ??= {})[t.lang] = t.value;
      return send(res, 200, { horizons: HORIZONS, categories: cats, texts });
    }
    if (p === '/api/instruments' && m === 'GET') {
      const q = u.searchParams, mode = q.get('mode');
      return send(res, 200, { items: service.list({ cat: q.get('cat') || undefined, q: (q.get('q') || '').slice(0, 50), mode: mode === 'live' || mode === 'otc' ? mode : undefined }) });
    }
    let r = p.match(/^\/api\/instruments\/(.+)\/candles$/);
    if (r && m === 'GET') return send(res, 200, await service.chart(decodeURIComponent(r[1]), Number(u.searchParams.get('hz')) || 60));
    if (p === '/api/signal' && m === 'POST') {
      if (!rlSignal.hit(rateKey(req))) return send(res, 429, { error: 'too_many', message: 'Too many requests' });
      const b = await body(req);
      return send(res, 200, await service.createSignal(String(b.id ?? ''), Number(b.hz), LANGS[b.lang] || 'English'));
    }
    if (p === '/api/signals' && m === 'GET') return send(res, 200, { items: service.signals({ id: u.searchParams.get('id') || undefined, limit: Math.min(Number(u.searchParams.get('limit')) || 20, 100) }) });
    if (p === '/api/stats' && m === 'GET') return send(res, 200, service.stats());
    return send(res, 404, { error: 'not_found', message: 'Not found' });
  }

  function serveStatic(req, res, u) {
    let rel = decodeURIComponent(u.pathname); if (rel === '/') rel = '/index.html'; if (rel === '/admin') rel = '/admin.html';
    const file = path.normalize(path.join(PUB, rel));
    if (!file.startsWith(PUB + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404, SEC); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', ...(file.endsWith('admin.html') || file.endsWith('admin.js') ? SEC : SEC_APP) });
    fs.createReadStream(file).pipe(res);
  }

  return http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://x'), m = req.method;
      if (!rlAll.hit(ip(req))) return send(res, 429, { error: 'too_many', message: 'Too many requests' });
      if (u.pathname.startsWith('/api/admin/')) return await admin(req, res, u, m);
      if (u.pathname.startsWith('/api/')) return await api(req, res, u, m);
      return serveStatic(req, res, u);
    } catch (e) {
      if (e instanceof ServiceError) return send(res, e.http, { error: e.code, message: e.message });
      console.error(JSON.stringify({ level: 'error', msg: e.message })); send(res, 500, { error: 'internal', message: 'Internal error' });
    }
  });
}

export function build(env = process.env) {
  const db = openDb(env.DB_FILE || 'data/aimeta.db'); seed(db);
  const service = new SignalService({ db, providers: { binance: new BinanceProvider(), twelvedata: new TwelveDataProvider() } });
  return { db, service, server: createApp({ db, service, secureCookie: env.COOKIE_SECURE === '1', trustProxy: env.TRUST_PROXY === '1', botToken: env.BOT_TOKEN || '' }) };
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  const { service, server } = build(), port = Number(process.env.PORT) || 3000, host = process.env.HOST || '127.0.0.1';
  setInterval(() => service.verifyDue().catch((e) => console.error(JSON.stringify({ level: 'error', msg: e.message }))), 5000);
  server.listen(port, host, () => console.log(JSON.stringify({ level: 'info', msg: `AIMETA SIGNAL on http://${host}:${port}` })));
}
